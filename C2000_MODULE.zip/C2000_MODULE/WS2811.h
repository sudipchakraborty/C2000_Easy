#ifndef WS2811_H_
#define WS2811_H_



#define     WS2811_LED_COUNT   38
//_______________________________________________________________________________________________________________________
struct WS2811_RGB_LED
{
    unsigned char R;
    unsigned char G;
    unsigned char B;
};
//_______________________________________________________________________________________________________________________
void WS2811_Init(void);
void WS2811_PIN_Test(void);
void WS2811_Update_LED(unsigned int index, unsigned char R,unsigned char G, unsigned char B);
void Fill_And_Update(unsigned char R,unsigned char G,unsigned char B);
void WS2811_Fill(unsigned char R,unsigned char G,unsigned char B);
void WS2811_update(void);
void WS2811_Send_Single_RGB_LED(unsigned char LED_R,unsigned char LED_G, unsigned char LED_B);
void WS2811_send_Bit_1(void);
void WS2811_send_Bit_0(void);

#endif
