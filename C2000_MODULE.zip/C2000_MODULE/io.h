/*
 * io.h
 *
 *  Created on: 23-Feb-2022
 *      Author: chand
 */

#ifndef IO_H_
#define IO_H_

#define     set_as_out  1
#define     set_as_In   0

void pinMode(unsigned char pin, unsigned char direction);
void digitalWrite(unsigned char pin, unsigned char val);
unsigned char digitalRead(unsigned char pin);
void toggle(unsigned char pin);



#endif /* ANORA_DIO_IO_H_ */
