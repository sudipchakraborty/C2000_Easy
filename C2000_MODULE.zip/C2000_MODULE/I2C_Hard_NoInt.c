#include "DSP28x_Project.h"

// Clock Settings for I2C module
#define SYSCLKOUT F_CPU // Frequency of I2C i/p clk
#define MODCLK    10*10^6 // Frequency of module clk must be between 7-10Mhz, selecting 10Mhz
#define CLKL      100      // Clock high
#define CLKH      100       // clock low
//_______________________________________________________________________________________________________________________
void I2C_Hard_NoInt_Init(void)
{
    EALLOW;
    PieCtrlRegs.PIEIER8.bit.INTx1 = 1;
    IER |= 0x0080;

  //  GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;    // Enable pull-up for GPIO32 (SDAA)
  //  GpioCtrlRegs.GPBPUD.bit.GPIO33 = 0;       // Enable pull-up for GPIO33 (SCLA)

    GpioCtrlRegs.GPBQSEL1.bit.GPIO32 = 3;  // Asynch input GPIO32 (SDAA)
    GpioCtrlRegs.GPBQSEL1.bit.GPIO33 = 3;  // Asynch input GPIO33 (SCLA)

    GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 1;   // Configure GPIO32 for SDAA operation
    GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 1;   // Configure GPIO33 for SCLA operation
    EDIS;
    /////////////////////////////////////
    I2caRegs.I2CMDR.bit.IRS = 0;                     // Reset & disable I2C module
  //  I2caRegs.I2CPSC = (SYSCLKOUT / MODCLK )- 1;  // Setting the prescalar value
    I2caRegs.I2CCLKL = CLKL;                         // CLOCK LOW
    I2caRegs.I2CCLKH = CLKH;                         // CLOCK HIGH
    I2caRegs.I2CIER.bit.SCD = 1;                    // Stop condition detected interrupt enable

    I2caRegs.I2CIER.bit.XRDY = 1;                   // Transmit-data-ready interrupt enable, do NOT use with FIFO
    I2caRegs.I2CIER.bit.RRDY = 1;                   // Receive-data-ready interrupt enable, do NOT use with FIFO

    I2caRegs.I2CMDR.bit.FREE = 1;                    // I2C module continues to run at a breakpoint
    I2caRegs.I2CMDR.bit.IRS = 1;                     // Enable I2C module
}
//_______________________________________________________________________________________________________________________
void I2C_Hard_NoInt_setAddress(unsigned char address)
{
    I2caRegs.I2CSAR = address;
}
//_______________________________________________________________________________________________________________________
void I2C_Hard_NoInt_setCount(unsigned char count)
{
    I2caRegs.I2CCNT = count;
}
//_______________________________________________________________________________________________________________________
/*
 * Function twi_readFrom
 * Desc     attempts to become twi bus master and read a
 *          series of bytes from a device on the bus
 * Input    address: 7bit i2c device address
 *          data: pointer to byte array
 *          length: number of bytes to read into array
 *          sendStop: Boolean indicating whether to send a stop at the end
 * Output   number of bytes read
 */
//_______________________________________________________________________________________________________________________
unsigned char I2C_Hard_NoInt_readFrom(unsigned char address, unsigned char length, unsigned char sendStop)
{
    // wait until twi is ready
    while(I2caRegs.I2CSTR.bit.BB == 1);
    while(I2caRegs.I2CMDR.bit.STP == 1); // Wait until the I2C bus is not busy

    // initialize buffer iteration vars
  //  twi_rxBufferIndex = 0;
  //  twi_rxBufferLength = length;

  // build sla+w, slave device address + w bit
    I2C_Hard_NoInt_setAddress(address);
    I2C_Hard_NoInt_setCount(length);

    if(sendStop)
    {
        I2caRegs.I2CMDR.bit.STP = 1;              // generate STOP condition when internal data counter -> 0
    }
    I2caRegs.I2CMDR.bit.MST = 1;                  // Master mode
    I2caRegs.I2CMDR.bit.TRX = 0;                  // not transmitter
    I2caRegs.I2CMDR.bit.STT = 1;                  // generate START condition on I2C bus
    I2caRegs.I2CMDR.bit.IRS = 1;                  // I2C module enabled
    // after STT, address in I2CSAR is automatically sent

    unsigned int i;

    while(I2caRegs.I2CSTR.bit.RRDY == 0);
    i = I2caRegs.I2CDRR;
    return i;
}
//_______________________________________________________________________________________________________________________
/*
 * Function twi_writeTo
 * Desc     attempts to become twi bus master and write a
 *          series of bytes to a device on the bus
 * Input    address: 7bit i2c device address
 *          data: pointer to byte array
 *          length: number of bytes in array
 *          wait: boolean indicating to wait for write or not
 *          sendStop: boolean indicating whether or not to send a stop at the end
 * Output   0 .. success
 *          1 .. length to long for buffer
 *          2 .. address send, NACK received
 *          3 .. data send, NACK received
 *          4 .. other twi error (lost bus arbitration, bus error, ..)
 */
//_______________________________________________________________________________________________________________________
unsigned char I2C_Hard_NoInt_writeTo(unsigned char address, unsigned char data, unsigned char length, unsigned char wait, unsigned char sendStop)
{

    // wait until twi is ready
    while(I2caRegs.I2CSTR.bit.BB == 1);
    while(I2caRegs.I2CMDR.bit.STP == 1); // Wait until the I2C bus is not busy

  // initialize buffer iteration vars
  //  twi_txBufferIndex = 0;
 //   twi_txBufferLength = length;

  //Set the slave address
    I2C_Hard_NoInt_setAddress(address);

  //Set the number of bytes to transmit
    I2C_Hard_NoInt_setCount(length);

    I2caRegs.I2CMDR.bit.MST = 1;    //Master mode
    I2caRegs.I2CMDR.bit.TRX = 1;    //I2C module is a transmitter
    I2caRegs.I2CMDR.bit.STT = 1;    //generate START condition on I2C bus
    I2caRegs.I2CMDR.bit.IRS = 1;    //I2C module enabled
    if(sendStop)
    {
        I2caRegs.I2CMDR.bit.STP = 1;
    }
    // after STT, address in I2CSAR is automatically sent


        //wait for transmit register to be ready
        while(I2caRegs.I2CSTR.bit.XRDY == 0);
        // copy data to output register
         I2caRegs.I2CDXR=data;

    return length;
}
//_______________________________________________________________________________________________________________________
/*
 * Function twi_transmit
 * Desc     fills slave tx buffer with data
 *          must be called in slave tx event callback
 * Input    data: pointer to byte array
 *          length: number of bytes in array
 * Output   1 length too long for buffer
 *          2 not slave transmitter
 *          0 ok
 */
//_______________________________________________________________________________________________________________________
void I2C_Hard_NoInt_stop(void)
{
    I2caRegs.I2CMDR.bit.STP = 1;
}
//_______________________________________________________________________________________________________________________
























//#include "DSP28x_Project.h"
//
//void   I2CA_Init(void);
//Uint16 I2CA_WriteData(struct I2CMSG *msg);
//Uint16 I2CA_ReadData(struct I2CMSG *msg);
//__interrupt void i2c_int1a_isr(void);
//void pass(void);
//void fail(void);
//
//#define I2C_SLAVE_ADDR       0x6F   // 0x50   RTC=0x6F
//#define I2C_NUMBYTES          2
//#define I2C_EEPROM_HIGH_ADDR  0x00
//#define I2C_EEPROM_LOW_ADDR   0x00
//
//
//void My_I2CA_Init(void);
//Uint16 My_I2CA_WriteData(Uint16 tx_adress, Uint16 tx_data);
////Uint16 My_I2CA_WriteData(Uint16 tx_adress, Uint16 *tx_data, Uint16 NumOfBytes);
//Uint16 My_I2CA_ReadData(Uint16 rx_adress, Uint16 *rx_data, Uint16 NumOfBytes);
////
//// Global variables
//// Two bytes will be used for the outgoing address,
//// thus only setup 14 bytes maximum
////
//struct I2CMSG I2cMsgOut1={I2C_MSGSTAT_SEND_WITHSTOP,
//                          I2C_SLAVE_ADDR,
//                          I2C_NUMBYTES,
//                          I2C_EEPROM_HIGH_ADDR,
//                          I2C_EEPROM_LOW_ADDR,
//                          0x32,                   // Msg Byte 1
//                          0x44};                  // Msg Byte 2
//
//struct I2CMSG I2cMsgIn1={ I2C_MSGSTAT_SEND_NOSTOP,
//                          I2C_SLAVE_ADDR,
//                          I2C_NUMBYTES,
//                          I2C_EEPROM_HIGH_ADDR,
//                          I2C_EEPROM_LOW_ADDR};
//
//struct I2CMSG *CurrentMsgPtr;                // Used in __interrupts
//Uint16 PassCount;
//Uint16 FailCount;
////___________________________________________________________________________________________________________________________________________________________________________________________________
//void main(void)
//{
//    Uint16 Error;
//    Uint16 i;
//
//    EALLOW;
//          GpioCtrlRegs.GPAMUX2.bit.GPIO25=0;
//          GpioCtrlRegs.GPADIR.bit.GPIO25=1;
//    EDIS;
//
//    GpioDataRegs.GPADAT.bit.GPIO25=0;
//
//    CurrentMsgPtr = &I2cMsgOut1;
//    InitSysCtrl();
//    InitI2CGpio();
//    DINT;
//    InitPieCtrl();
//    IER = 0x0000;
//    IFR = 0x0000;
//    InitPieVectTable();
//
//
// //   My_I2CA_Init();
//
////    while(1)
////    {
////        for(i=0;i<50000;i++);
////      //  My_I2CA_WriteData(0x00,0x34);
////     //   for(i=0;i<50000;i++);
////        My_I2CA_ReadData(0x00, &i, 1);
////
////    }
//
//
//
//
//    EALLOW;    // This is needed to write to EALLOW protected registers
//    PieVectTable.I2CINT1A = &i2c_int1a_isr;
//    EDIS;   // This is needed to disable write to EALLOW protected registers
//
//    I2CA_Init();
//    PassCount = 0;
//    FailCount = 0;
//
//    for (i = 0; i < I2C_MAX_BUFFER_SIZE; i++)
//    {
//        I2cMsgIn1.MsgBuffer[i] = 0x0000;
//    }
//
//    PieCtrlRegs.PIEIER8.bit.INTx1 = 1;
//    IER |= M_INT8;
//    EINT;
//
////
////
//    for(;;)
//    {
//        if(I2cMsgOut1.MsgStatus == I2C_MSGSTAT_SEND_WITHSTOP)
//        {
//            Error = I2CA_WriteData(&I2cMsgOut1);
//            if (Error == I2C_SUCCESS)
//            {
//                CurrentMsgPtr = &I2cMsgOut1;
//                I2cMsgOut1.MsgStatus = I2C_MSGSTAT_WRITE_BUSY;
//            }
//        }
////        //------------------------------------------------
//
//        //////////////////////////////////////////////////
//        if (I2cMsgOut1.MsgStatus == I2C_MSGSTAT_INACTIVE)
//        {
//            if(I2cMsgIn1.MsgStatus == I2C_MSGSTAT_SEND_NOSTOP)
//            {
//                while(I2CA_ReadData(&I2cMsgIn1) != I2C_SUCCESS)
//                {
//                }
//                CurrentMsgPtr = &I2cMsgIn1;
//                I2cMsgIn1.MsgStatus = I2C_MSGSTAT_SEND_NOSTOP_BUSY;
//            }
//            else if(I2cMsgIn1.MsgStatus == I2C_MSGSTAT_RESTART)
//            {
//                while(I2CA_ReadData(&I2cMsgIn1) != I2C_SUCCESS)
//                {
//                }
//                CurrentMsgPtr = &I2cMsgIn1;
//                I2cMsgIn1.MsgStatus = I2C_MSGSTAT_READ_BUSY;
//            }
//        }  // end of read section
//
//
//
//
//    }   // end of for(;;)
//
//}   // end of main
////___________________________________________________________________________________________________________________________________________________________________________________________________
//void My_I2CA_Init(void)
//
//{
//   I2caRegs.I2CSAR =0x6F;// 0x0050; // Slave address - EEPROM control code
//   I2caRegs.I2CCLKL = 10; // NOTE: must be non zero
//   I2caRegs.I2CCLKH = 5; // NOTE: must be non zero
//   //I2caRegs.I2CIER.all = 0x24; // Enable SCD & ARDY interrupts
//   I2caRegs.I2CIER.all = 0; // Disable SCD & ARDY interrupts
//   I2caRegs.I2CFFTX.bit.I2CFFEN = 0;// Disable FIFO mode
//   I2caRegs.I2CMDR.all = 0x0C20; // Take I2C out of reset
//   while(I2caRegs.I2CSTR.bit.BB);
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//Uint16 My_I2CA_WriteData(Uint16 tx_adress, Uint16 tx_data)
//{
//    char i;
//
//    // <step-01,  check previous stop detected
//    if (I2caRegs.I2CMDR.bit.STP == 1)   return I2C_STP_NOT_READY_ERROR;
//    /////////////////////////////////////////
//    while(I2caRegs.I2CSTR.bit.BB  !=  0) ;  // check BUS Busy
//
//    I2caRegs.I2CSAR = I2C_SLAVE_ADDR;
//    I2caRegs.I2CCNT = 2;
//    I2caRegs.I2CMDR.bit.TRX = 1;            // Transmitter Mode
//
//    I2caRegs.I2CMDR.bit.STT = 1;            // create start in I2C Bus
//
//
//  //  if(I2caRegs.I2CSTR.bit.NACK)    // 1=ACK Received
//
//    I2caRegs.I2CDXR = tx_adress;
//    I2caRegs.I2CDXR = tx_data;
//    I2caRegs.I2CMDR.bit.STP = 1;
//
//
////
////    if(I2caRegs.I2CSTR.bit.XRDY | I2caRegs.I2CSTR.bit.ARDY)
////    {
////        I2caRegs.I2CDXR = tx_adress;
////
////        for (i=0; i<NumOfBytes; i++)
////        {
////            if(I2caRegs.I2CSTR.bit.NACK)
////            {
////                return 3;
////            }
////            if(I2caRegs.I2CSTR.bit.XRDY | I2caRegs.I2CSTR.bit.ARDY)
////            {
////               I2caRegs.I2CDXR = *tx_data;
////               tx_data++;
////            }
////            else
////            {
////                return 2;
////            }
////        }
////    }
////    else
////    {
////        return 1;
////    }
////
////    I2caRegs.I2CMDR.bit.STP = 1;
////   return 0;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//Uint16 My_I2CA_ReadData(Uint16 rx_adress, Uint16 *rx_data, Uint16 NumOfBytes)
//{
//    char i;
//    while(I2caRegs.I2CSTR.bit.BB  !=  0) ;
////  I2caRegs.I2CMDR.all = 0;
//    I2caRegs.I2CSAR = I2C_SLAVE_ADDR;
//    I2caRegs.I2CCNT = 1;
////  I2caRegs.I2CMDR.all = 0x6E20;
////  I2caRegs.I2CMDR.all = 0x2620;
//    I2caRegs.I2CMDR.bit.TRX = 1;
////  I2caRegs.I2CMDR.bit.IRS = 1;
//    I2caRegs.I2CMDR.bit.STT = 1;
////   while(I2caRegs.I2CSTR.bit.BB  !=  0) ;
//
//  while((I2caRegs.I2CSTR.bit.XRDY | I2caRegs.I2CSTR.bit.ARDY)==0);
//
//    if(I2caRegs.I2CSTR.bit.XRDY | I2caRegs.I2CSTR.bit.ARDY)
//    {
//        I2caRegs.I2CDXR = rx_adress;
//
//        if(I2caRegs.I2CSTR.bit.XRDY | I2caRegs.I2CSTR.bit.ARDY)
//        {
//            // I2caRegs.I2CMDR.all = 0;
//            I2caRegs.I2CSAR = I2C_SLAVE_ADDR;
//            I2caRegs.I2CCNT = NumOfBytes;
//            I2caRegs.I2CMDR.bit.STP = 1;
//            I2caRegs.I2CMDR.bit.TRX = 0;
//            while(I2caRegs.I2CSTR.bit.BB  !=  0) ;
//            I2caRegs.I2CMDR.bit.IRS = 1;
//            // I2caRegs.I2CMDR.bit.STT = 1;
//            // I2caRegs.I2CMDR.all = 0x2C20; // Send restart as master receiver
//          //  while(I2caRegs.I2CSTR.bit.BB  !=  0) ;
//
//          //  for (i=0; i<NumOfBytes; i++)
//        //    {
//                while((I2caRegs.I2CSTR.bit.XRDY | I2caRegs.I2CSTR.bit.ARDY)==0);
//
////                if(I2caRegs.I2CSTR.bit.RRDY | I2caRegs.I2CSTR.bit.ARDY)
////                {
//                    i = I2caRegs.I2CDRR;
//                    rx_data++;
////                }
////                else
////                {
////                    return 4;
////                }
//           // }
//        }
//        else
//        {
//          return 2;
//        }
//        return 0;
//    }
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//
//
//
//
//
//
//
//
//
//
//
//void I2CA_Init(void)
//{
//    //
//    // Initialize I2C
//    //
//    I2caRegs.I2CSAR = I2C_SLAVE_ADDR;   //0x0050;        // Slave address - EEPROM control code
//
//    I2caRegs.I2CPSC.all = 6;         // Prescaler - need 7-12 Mhz on module clk
//    I2caRegs.I2CCLKL = 10;           // NOTE: must be non zero
//    I2caRegs.I2CCLKH = 5;            // NOTE: must be non zero
//    I2caRegs.I2CIER.all = 0x24;      // Enable SCD & ARDY __interrupts
//
//    I2caRegs.I2CMDR.all = 0x0020;     // Take I2C out of reset
//                                      // Stop I2C when suspended
//
//    I2caRegs.I2CFFTX.all = 0x6000;    // Enable FIFO mode and TXFIFO
//    I2caRegs.I2CFFRX.all = 0x2040;    // Enable RXFIFO, clear RXFFINT,
//
//    return;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//Uint16 I2CA_WriteData(struct I2CMSG *msg)
//{
//    Uint16 i;
//
//    if (I2caRegs.I2CMDR.bit.STP == 1)
//    {
//        return I2C_STP_NOT_READY_ERROR;
//    }
//
//    I2caRegs.I2CSAR = msg->SlaveAddress;
//
//    //
//    // Check if bus busy
//    //
//    if (I2caRegs.I2CSTR.bit.BB == 1)
//    {
//        return I2C_BUS_BUSY_ERROR;
//    }
//
//    //
//    // Setup number of bytes to send
//    // MsgBuffer + Address
//    //
//    I2caRegs.I2CCNT = msg->NumOfBytes+1;
//
//    //
//    // Setup data to send
//    //
//    I2caRegs.I2CDXR = msg->MemoryHighAddr;
//    I2caRegs.I2CDXR = msg->MemoryLowAddr;
//    for (i=0; i<msg->NumOfBytes; i++)
//    {
//        I2caRegs.I2CDXR = *(msg->MsgBuffer+i);
//    }
//
//    //
//    // Send start as master transmitter
//    //
//    I2caRegs.I2CMDR.all = 0x6E20;
//
//    return I2C_SUCCESS;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//Uint16 I2CA_ReadData(struct I2CMSG *msg)
//{
//    //
//    // Wait until the STP bit is cleared from any previous master communication.
//    // Clearing of this bit by the module is delayed until after the SCD bit is
//    // set. If this bit is not checked prior to initiating a new message, the
//    // I2C could get confused.
//    //
//    if (I2caRegs.I2CMDR.bit.STP == 1)
//    {
//        return I2C_STP_NOT_READY_ERROR;
//    }
//
//    I2caRegs.I2CSAR = msg->SlaveAddress;
//
//    if(msg->MsgStatus == I2C_MSGSTAT_SEND_NOSTOP)
//    {
//        if (I2caRegs.I2CSTR.bit.BB == 1)
//        {
//         return I2C_BUS_BUSY_ERROR;
//        }
//        I2caRegs.I2CCNT = 2;
//        I2caRegs.I2CDXR = msg->MemoryHighAddr;
//        I2caRegs.I2CDXR = msg->MemoryLowAddr;
//        I2caRegs.I2CMDR.all = 0x2620;            // Send data to setup EEPROM address
//    }
//    else if(msg->MsgStatus == I2C_MSGSTAT_RESTART)
//    {
//        I2caRegs.I2CCNT = msg->NumOfBytes;    // Setup how many bytes to expect
//        I2caRegs.I2CMDR.all = 0x2C20;         // Send restart as master receiver
//    }
//
//    return I2C_SUCCESS;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//__interrupt void i2c_int1a_isr(void)     // I2C-A
//{
//    Uint16 IntSource, i;
//
//    //
//    // Read __interrupt source
//    //
//    IntSource = I2caRegs.I2CISRC.all;
//
//    //
//    // Interrupt source = stop condition detected
//    //
//    if(IntSource == I2C_SCD_ISRC)
//    {
//        //
//        // If completed message was writing data, reset msg to inactive state
//        //
//        if (CurrentMsgPtr->MsgStatus == I2C_MSGSTAT_WRITE_BUSY)
//        {
//            CurrentMsgPtr->MsgStatus = I2C_MSGSTAT_INACTIVE;
//        }
//        else
//        {
//            //
//            // If a message receives a NACK during the address setup portion of the
//            // EEPROM read, the code further below included in the register access ready
//            // __interrupt source code will generate a stop condition. After the stop
//            // condition is received (here), set the message status to try again.
//            // User may want to limit the number of retries before generating an error.
//            //
//            if(CurrentMsgPtr->MsgStatus == I2C_MSGSTAT_SEND_NOSTOP_BUSY)
//            {
//                CurrentMsgPtr->MsgStatus = I2C_MSGSTAT_SEND_NOSTOP;
//            }
//            //
//            // If completed message was reading EEPROM data, reset msg to inactive state
//            // and read data from FIFO.
//             else if (CurrentMsgPtr->MsgStatus == I2C_MSGSTAT_READ_BUSY)
//             {
//                CurrentMsgPtr->MsgStatus = I2C_MSGSTAT_INACTIVE;
//                for(i=0; i < I2C_NUMBYTES; i++)
//                {
//                  CurrentMsgPtr->MsgBuffer[i] = I2caRegs.I2CDRR;
//                }
//
//                {
//                    // Check received data
//                    for(i=0; i < I2C_NUMBYTES; i++)
//                    {
//                        if(I2cMsgIn1.MsgBuffer[i] == I2cMsgOut1.MsgBuffer[i])
//                        {
//                            PassCount++;
//                        }
//                        else
//                        {
//                            FailCount++;
//                        }
//                    }
//                    if(PassCount == I2C_NUMBYTES)
//                    {
//                        pass();
//                    }
//                    else
//                    {
//                        fail();
//                    }
//                }
//            }
//        }
//    }  // end of stop condition detected
//
//    //
//    // Interrupt source = Register Access Ready
//    // This __interrupt is used to determine when the EEPROM address setup portion of the
//    // read data communication is complete. Since no stop bit is commanded, this flag
//    // tells us when the message has been sent instead of the SCD flag. If a NACK is
//    // received, clear the NACK bit and command a stop. Otherwise, move on to the read
//    // data portion of the communication.
//    //
//    else if(IntSource == I2C_ARDY_ISRC)
//    {
//        if(I2caRegs.I2CSTR.bit.NACK == 1)
//        {
//            I2caRegs.I2CMDR.bit.STP = 1;
//            I2caRegs.I2CSTR.all = I2C_CLR_NACK_BIT;
//        }
//        else if(CurrentMsgPtr->MsgStatus == I2C_MSGSTAT_SEND_NOSTOP_BUSY)
//        {
//            CurrentMsgPtr->MsgStatus = I2C_MSGSTAT_RESTART;
//        }
//    }  // end of register access ready
//
//    else
//    {
//        //
//        // Generate some error due to invalid __interrupt source
//        //
//        asm("   ESTOP0");
//    }
//
//    //
//    // Enable future I2C (PIE Group 8) __interrupts
//    //
//    PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//void pass()
//{
//    asm("   ESTOP0");
//    for(;;);
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//void fail()
//{
//    asm("   ESTOP0");
//    for(;;);
//}
////___________________________________________________________________________________________________________________________________________________________________________________________________
//
////
//// End of file.
////
