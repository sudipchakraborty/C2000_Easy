#include "F2805x_Cla_typedefs.h"// F2806x CLA Type definitions
#include "F2805x_Device.h"     // F2805x Headerfile Include File
#include "F2805x_Examples.h"   // F2805x Examples Include File

void sciC_NoInt_Init(void);
unsigned char sciC_NoInt_Read_Char(void);
void sciC_NoInt_send_char(unsigned char val);
void sciC_NoInt_msg(char * msg);
unsigned char sciC_NoInt_Send_Receive(unsigned char *bfr_tx, unsigned char *bfr_rx);

unsigned char sciC_NoInt_rx_count;
//________________________________________________________________________________________________________________________________________________________
void sciC_NoInt_Init(void)
{
        Uint16 ReceivedChar;
        char *msg;
        unsigned int delay_reg;

        EALLOW;
          GpioCtrlRegs.GPBPUD.bit.GPIO39 = 0;   // Enable pull-up for GPIO39 (SCIRXDC)
          GpioCtrlRegs.GPBPUD.bit.GPIO42 = 0;   // Enable pull-up for GPIO42 (SCITXDC)
          GpioCtrlRegs.GPBQSEL1.bit.GPIO39 = 3; // Asynch input GPIO39 (SCIRXDC)
          GpioCtrlRegs.GPBMUX1.bit.GPIO39 = 2;  // Configure GPIO39 for SCIRXDC
          GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 2;  // Configure GPIO42 for SCITXDC
        EDIS;
        /////////////////////////////////////////
        ScicRegs.SCIFFTX.all=0xE040;
        ScicRegs.SCIFFRX.all=0x2044;
        ScicRegs.SCIFFCT.all=0x0;

        ScicRegs.SCICCR.all = 0x0007;            // 1 stop bit,  No loopback // No parity, 8 char bits, // async mode, idle-line protocol
        ScicRegs.SCICTL1.all = 0x0003;           // enable TX, RX, internal SCICLK, // Disable RX ERR, SLEEP, TXWAKE
        ScicRegs.SCICTL2.all = 0x0003;
        ScicRegs.SCICTL2.bit.TXINTENA = 1;
        ScicRegs.SCICTL2.bit.RXBKINTENA = 1;
        ScicRegs.SCIHBAUD= 0x0000;
        ScicRegs.SCILBAUD=15;                   // Baud Rate: 115200
        ScicRegs.SCICTL1.all = 0x0023;          // Relinquish SCI from Reset
}
//__________________________________________________________________________________________________________________________________________________________
unsigned char sciC_NoInt_Read_Char(void)
{
  while(ScicRegs.SCIFFRX.bit.RXFFST !=1);
  return ScicRegs.SCIRXBUF.all;
}
//__________________________________________________________________________________________________________________________________________________________
void sciC_NoInt_send_char(unsigned char val)
{
    while (ScicRegs.SCIFFTX.bit.TXFFST != 0);
    ScicRegs.SCITXBUF=val;
}
//__________________________________________________________________________________________________________________________________________________________
void sciC_NoInt_msg(char * msg)
{
    int i;
    i = 0;
    while(msg[i] != '\0')
    {
        sciC_NoInt_send_char(msg[i]);
        i++;
    }
}
//__________________________________________________________________________________________________________________________________________________________
unsigned char sciC_NoInt_Send_Receive(unsigned char *bfr_tx, unsigned char *bfr_rx)
{
    double TimeOut;

    sciC_NoInt_msg(bfr_tx);
    TimeOut=0;
    sciC_NoInt_rx_count=0;

    while(1)
    {
        if(ScicRegs.SCIFFRX.bit.RXFFST==1)
        {
            *bfr_rx=ScicRegs.SCIRXBUF.all;
            sciC_NoInt_rx_count++;
            TimeOut=0;
        }
        else
        {
            TimeOut++;
            if(TimeOut>100000)return;
        }
    }
}
//__________________________________________________________________________________________________________________________________________________________












