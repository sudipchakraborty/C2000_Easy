


#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include "pwm.h"



// Configure which ePWM timer __interrupts are enabled at the PIE level:
// 1 = enabled,  0 = disabled
#define PWM1_INT_ENABLE  1
#define PWM2_INT_ENABLE  1
#define PWM3_INT_ENABLE  1

// Configure the period for each timer
#define PWM1_TIMER_TBPRD   0x1FFF
#define PWM2_TIMER_TBPRD   0x1FFF
#define PWM3_TIMER_TBPRD   0x1FFF

// Make this long enough so that we can see an LED toggle
#define DELAY 1000000L

// Functions that will be run from RAM need to be assigned to
// a different section.  This section will then be mapped using
// the linker cmd file.
#pragma CODE_SECTION(epwm1_timer_isr, "ramfuncs");
#pragma CODE_SECTION(epwm2_timer_isr, "ramfuncs");

// Prototype statements for functions found within this file.
__interrupt void epwm1_timer_isr(void);
__interrupt void epwm2_timer_isr(void);
__interrupt void epwm3_timer_isr(void);
void InitEPwmTimer(void);

// Global variables used in this example
Uint32  EPwm1TimerIntCount;
Uint32  EPwm2TimerIntCount;
Uint32  EPwm3TimerIntCount;
Uint32  LoopCount;


void InitEPwmTimer()
{
   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;      // Stop all the TB clocks
   EDIS;

   InitEPwm1Gpio();
   InitEPwm2Gpio();
   InitEPwm3Gpio();

   // Setup Sync
   EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;  // Pass through
   EPwm2Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;  // Pass through
   EPwm3Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;  // Pass through

   // Allow each timer to be sync'ed

   EPwm1Regs.TBCTL.bit.PHSEN = TB_ENABLE;
   EPwm2Regs.TBCTL.bit.PHSEN = TB_ENABLE;
   EPwm3Regs.TBCTL.bit.PHSEN = TB_ENABLE;

   EPwm1Regs.TBPHS.half.TBPHS = 100;
   EPwm2Regs.TBPHS.half.TBPHS = 200;
   EPwm3Regs.TBPHS.half.TBPHS = 300;

   EPwm1Regs.TBPRD = PWM1_TIMER_TBPRD;
   EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;    // Count up
   EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
   EPwm1Regs.ETSEL.bit.INTEN = PWM1_INT_ENABLE;  // Enable INT
   EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 1st event


   EPwm2Regs.TBPRD = PWM2_TIMER_TBPRD;
   EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;     // Count up
   EPwm2Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;      // Enable INT on Zero event
   EPwm2Regs.ETSEL.bit.INTEN = PWM2_INT_ENABLE;   // Enable INT
   EPwm2Regs.ETPS.bit.INTPRD = ET_2ND;            // Generate INT on 2nd event


   EPwm3Regs.TBPRD = PWM3_TIMER_TBPRD;
   EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;     // Count up
   EPwm3Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;      // Enable INT on Zero event
   EPwm3Regs.ETSEL.bit.INTEN = PWM3_INT_ENABLE;   // Enable INT
   EPwm3Regs.ETPS.bit.INTPRD = ET_3RD;            // Generate INT on 3rd event

   EALLOW;
   SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;         // Start all the timers synced
   EDIS;
}





// This ISR MUST be executed from RAM as it will put the Flash into Sleep
// Interrupt routines uses in this example:
__interrupt void epwm1_timer_isr(void)
{
   // Put the Flash to sleep
   EALLOW;
   FlashRegs.FPWR.bit.PWR = FLASH_SLEEP;
   EDIS;

   EPwm1TimerIntCount++;

   // Clear INT flag for this timer
   EPwm1Regs.ETCLR.bit.INT = 1;

   // Acknowledge this __interrupt to receive more __interrupts from group 3
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

// This ISR MUST be executed from RAM as it will put the Flash into Standby
__interrupt void epwm2_timer_isr(void)
{
   EPwm2TimerIntCount++;

    // Put the Flash into standby
    EALLOW;
    FlashRegs.FPWR.bit.PWR = FLASH_STANDBY;
    EDIS;

   // Clear INT flag for this timer
   EPwm2Regs.ETCLR.bit.INT = 1;

   // Acknowledge this __interrupt to receive more __interrupts from group 3
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

__interrupt void epwm3_timer_isr(void)
{
   Uint16 i;

   EPwm3TimerIntCount++;

    // Short Delay to simulate some ISR Code
    for(i = 1; i < 0x01FF; i++) {}

   // Clear INT flag for this timer
   EPwm3Regs.ETCLR.bit.INT = 1;

   // Acknowledge this __interrupt to receive more __interrupts from group 3
   PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}



//
//
//
//
//#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
//
//#include "pwm.h"
//
//void main(void)
//{
//
//    InitSysCtrl();
//
//
//    DINT;
//        InitPieCtrl();
//    //    IER = 0x0000;
//    //    IFR = 0x0000;
//        InitPieVectTable();
//    //    PieVectTable.EPWM1_INT = &epwm1_timer_isr;
//    //    PieVectTable.EPWM2_INT = &epwm2_timer_isr;
//    //    PieVectTable.EPWM3_INT = &epwm3_timer_isr;
//    EDIS;
//
//  //  InitEPwmTimer();
//  //  memcpy(&RamfuncsRunStart,&RamfuncsLoadStart, (Uint32)&RamfuncsLoadSize);
//
//   // InitFlash();
//
//    // Initialize counters:
////    EPwm1TimerIntCount = 0;
////    EPwm2TimerIntCount = 0;
////    EPwm3TimerIntCount = 0;
// //   LoopCount = 0;
//
//    // Enable CPU INT3 which is connected to EPWM1-3 INT:
// //   IER |= M_INT3;
//
//    // Enable EPWM INTn in the PIE: Group 3 __interrupt 1-3
//  //  PieCtrlRegs.PIEIER3.bit.INTx1 = PWM1_INT_ENABLE;
//  //  PieCtrlRegs.PIEIER3.bit.INTx2 = PWM2_INT_ENABLE;
//  //  PieCtrlRegs.PIEIER3.bit.INTx3 = PWM3_INT_ENABLE;
//
//    // Enable global Interrupts and higher priority real-time debug events:
//  //  EINT;   // Enable Global __interrupt INTM
//  //  ERTM;   // Enable Global realtime __interrupt DBGM
//
//    // Step 6. IDLE loop. Just sit and loop forever (optional):
//    EALLOW;
//    GpioCtrlRegs.GPBMUX1.bit.GPIO34 = 0;
//    GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1;
//    EDIS;
//
//   for(;;)
//   {
//       // This loop will be __interrupted, so the overall
//       // delay between pin toggles will be longer.
//     //  DELAY_US(DELAY);
//     //  LoopCount++;
//     //  GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1;
//   }
//}
//
//
//
//
//
//
//
//
//
//
