#ifndef I2C_HARD_NOINT_H_
#define I2C_HARD_NOINT_H_



void I2C_Hard_NoInt_Init(void);
void I2C_Hard_NoInt_setAddress(unsigned char address);
void I2C_Hard_NoInt_setCount(unsigned char count);
unsigned char I2C_Hard_NoInt_readFrom(unsigned char address, unsigned char length, unsigned char sendStop);
uint8_t I2C_Hard_NoInt_writeTo(uint8_t address, uint8_t data, uint8_t length, uint8_t wait, uint8_t sendStop);
void I2C_Hard_NoInt_stop(void);



#endif /* I2C_SOFTWARE_H_ */
