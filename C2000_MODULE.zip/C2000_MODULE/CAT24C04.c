#include "F2805x_Cla_typedefs.h"    // F2806x CLA Type definitions
#include "F2805x_Device.h"          // F2805x Headerfile Include File
#include "I2C_Software.h"
#include "CAT24C04.h"
#include "io.h"

#define     CAT24C04_ADDRESS   0xA0 // 0x50

//_________________________________________________________________________________________________________________________________________________________
void CAT24C04_Init(void)
{
  pinMode(46, set_as_out);
  digitalWrite(46,0);
}
//_________________________________________________________________________________________________________________________________________________________
void CAT24C04_Write(unsigned char addr, unsigned char data)
{
    unsigned int i;

    I2C_Soft_Start();
    I2C_Soft_Write(CAT24C04_ADDRESS);
    I2C_Soft_Ack_Received();

    I2C_Soft_Write(addr);
    I2C_Soft_Ack_Received();

    I2C_Soft_Write(data);
    I2C_Soft_Ack_Received();

    I2C_Soft_Stop();
    for(i=0;i<3000;i++);   //3000
}
//_________________________________________________________________________________________________________________________________________________________
unsigned char CAT24C04_Read(unsigned char addr)
{
    unsigned char ret_val;

    I2C_Soft_Start();
    I2C_Soft_Write(CAT24C04_ADDRESS);
    I2C_Soft_Ack_Received();

    I2C_Soft_Write(addr);
    I2C_Soft_Ack_Received();
    I2C_Soft_Stop();

    I2C_Soft_Start();
    I2C_Soft_Write(CAT24C04_ADDRESS+1);
    I2C_Soft_Ack_Received();

    ret_val=I2C_Soft_Read(0);
    I2C_Soft_Stop();
    return ret_val;
}
//_________________________________________________________________________________________________________________________________________________________
void CAT24C04_Gets(unsigned char addr,unsigned char count,unsigned char *bfr)
{
    unsigned char i;

    for(i=0;i<count;i++)
    {
      *bfr=CAT24C04_Read(addr);
      addr++;
      bfr++;
    }
}
//_________________________________________________________________________________________________________________________________________________________
void CAT24C04_Puts(unsigned char addr,unsigned char count,unsigned char *bfr)
{
    unsigned char i;

    for(i=0;i<count;i++)
    {
      CAT24C04_Write(addr,*bfr);
      addr++;
      bfr++;
    }
}
//_________________________________________________________________________________________________________________________________________________________
