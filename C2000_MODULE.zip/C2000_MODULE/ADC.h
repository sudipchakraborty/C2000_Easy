#ifndef ADC_H_
#define ADC_H_

#include "F2805x_Device.h"     // F2805x Headerfile Include File

void ADC_Init(void);
__interrupt void adc_isr(void);
void ADC_Select_Channel(unsigned int ch_no);
unsigned int ADC_Get_Value(unsigned int channel);

Uint16 TempSensorVoltage;


//_______________________________________________________________________________________________________________________________________
void ADC_Init(void)
{
    EALLOW;  // This is needed to write to EALLOW protected register
    PieVectTable.ADCINT1 = &adc_isr;
    EDIS;    // This is needed to disable write to EALLOW protected registers

    EALLOW;
        SysCtrlRegs.PCLKCR0.bit.ADCENCLK = 1;
    EDIS;

    EALLOW;
        AdcRegs.ADCCTL1.bit.ADCBGPWD  = 1;      // Power ADC BG
        AdcRegs.ADCCTL1.bit.ADCREFPWD = 1;      // Power reference
        AdcRegs.ADCCTL1.bit.ADCPWDN   = 1;      // Power ADC
        AdcRegs.ADCCTL1.bit.ADCENABLE = 1;      // Enable ADC
        AdcRegs.ADCCTL1.bit.ADCREFSEL = 0;      // Select internal BG
    EDIS;

    EALLOW;
   AdcRegs.ADCCTL1.bit.INTPULSEPOS = 1;    //ADCINT1 trips after AdcResults latch
 //   AdcRegs.INTSEL1N2.bit.INT1E     = 1;    //Enabled ADCINT1
    AdcRegs.INTSEL1N2.bit.INT1CONT  = 0;    //Disable ADCINT1 Continuous mode
   AdcRegs.INTSEL1N2.bit.INT1SEL   = 1;    // setup EOC0 to trigger ADCINT1 to fire

    //
    // Set SOC0 channel select to ADCINA5
    // (which is internally connected to the temperature sensor)
    //
    AdcRegs.ADCSOC0CTL.bit.CHSEL    = 7;

    //
    // Set SOC1 channel select to ADCINA5
    // (which is internally connected to the temperature sensor)
    // errata workaround
    //
    AdcRegs.ADCSOC1CTL.bit.CHSEL    = 7;

    AdcRegs.ADCSOC0CTL.bit.TRIGSEL  = 5;    //set SOC1 start trigger on EPWM1A
    AdcRegs.ADCSOC1CTL.bit.TRIGSEL  = 5;        // Set SOC0 start trigger on EPWM1A errata workaround
    AdcRegs.ADCSOC0CTL.bit.ACQPS    = 36;       //set SOC0 S/H Window to 37 ADC Clock Cycles, (36 ACQPS plus 1)
    AdcRegs.ADCSOC1CTL.bit.ACQPS    = 36;   //set SOC1 S/H Window to 37 ADC Clock Cycles, (36 ACQPS plus 1) errata
    EDIS;

   PieCtrlRegs.PIEIER1.bit.INTx1 = 1;   // Enable INT 1.1 in the PIE
   IER |= M_INT1;                       // Enable CPU Interrupt 1
   EINT;                                // Enable Global __interrupt INTM
   ERTM;                           // Enable Global realtime __interrupt DBGM

    // Assumes ePWM1 clock is already enabled in InitSysCtrl();
    EPwm1Regs.ETSEL.bit.SOCAEN   = 1;        // Enable SOC on A group
    EPwm1Regs.ETSEL.bit.SOCASEL  = 4;        // Select SOC from CPMA on upcount
    EPwm1Regs.ETPS.bit.SOCAPRD   = 1;        // Generate pulse on 1st event
    EPwm1Regs.CMPA.half.CMPA     = 0x0080;   // Set compare A value
    EPwm1Regs.TBPRD              = 0xFFFF;   // Set period for ePWM1
    EPwm1Regs.TBCTL.bit.CTRMODE  = 0;        // count up and start
}
//____________________________________________________________________________________________________________________________________________________________________________________________________________
__interrupt void  adc_isr(void)
{
    TempSensorVoltage= AdcResult.ADCRESULT1;
    AdcRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;   // Acknowledge __interrupt to PIE
    return;
}
//____________________________________________________________________________________________________________________________________________________________________________________________________________
void ADC_Select_Channel(unsigned int ch_no)
{
    AdcRegs.ADCSOC0CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC1CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC2CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC3CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC4CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC5CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC6CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC7CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC8CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC9CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC10CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC11CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC12CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC13CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC14CTL.bit.CHSEL= ch_no;
    AdcRegs.ADCSOC15CTL.bit.CHSEL= ch_no;
}
//____________________________________________________________________________________________________________________________________________________________________________________________________________
unsigned int ADC_Get_Value(unsigned int channel)
{
    unsigned int i;
    ADC_Select_Channel(channel);

 //   EALLOW;
//    AdcRegs.INTSEL1N2.bit.INT1E     = 1;
//    EDIS;

    for(i=0;i<1000;i++);
 //   EALLOW;
 //   AdcRegs.INTSEL1N2.bit.INT1E     = 0;
 //   EDIS;
    return AdcResult.ADCRESULT1;
}
//____________________________________________________________________________________________________________________________________________________________________________________________________________













#endif /* ADC_H_ */
