


void CAT24C04_Init(void);
void CAT24C04_Write(unsigned char addr, unsigned char data);
unsigned char CAT24C04_Read(unsigned char addr);
void CAT24C04_Gets(unsigned char addr,unsigned char count,unsigned char *bfr);
void CAT24C04_Puts(unsigned char addr,unsigned char count,unsigned char *bfr);
