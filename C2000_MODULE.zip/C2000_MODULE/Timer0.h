#ifndef TIMER0_H_
#define TIMER0_H_

#include "DSP28x_Project.h"

__interrupt void timer0_isr(void);
void Timer0_Default_Config(void);
void Timer0_Start(void);
void Timer0_Stop(void);
void Timer0_Reload(void);
Uint32 Timer0_Read(void);
Uint32 Timer0_Read_Period(void);

extern struct CPUTIMER_VARS CpuTimer0;
//_________________________________________________________________________________________________________________
__interrupt void timer0_isr(void)
{
  //  CpuTimer0.InterruptCount++;
  //  GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1; // Toggle GPIO34 once per 500 ms

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
//_________________________________________________________________________________________________________________
void Timer0_Default_Config(void)
{
     float Freq;
    float Period;
    Uint32  temp;
    
    EALLOW;  // This is needed to write to EALLOW protected registers
     PieVectTable.TINT0 = &timer0_isr;
    EDIS;    // This is needed to disable write to EALLOW protected registers
    
    CpuTimer0.RegsAddr = &CpuTimer0Regs;
    CpuTimer0Regs.PRD.all  = 0xFFFFFFFF;
    
    CpuTimer0Regs.TPR.all  = 0;     // Initialize pre-scale counter to divide by 1 (SYSCLKOUT)
    CpuTimer0Regs.TPRH.all = 0;
    CpuTimer0Regs.TCR.bit.TSS = 1;    // Make sure timer is stopped
    CpuTimer0Regs.TCR.bit.TRB = 1;  // Reload all counter register with period value
    CpuTimer0.InterruptCount = 0;  // Reset __interrupt counters

    Freq=60;
    Period=50000;
    
    CpuTimer0.CPUFreqInMHz = Freq;
    CpuTimer0.PeriodInUSec = Period;
    temp = (long) (Freq * Period);
    CpuTimer0.RegsAddr->PRD.all = temp;
    
    // Set pre-scale counter to divide by 1 (SYSCLKOUT)
    CpuTimer0.RegsAddr->TPR.all  = 0;
    CpuTimer0.RegsAddr->TPRH.all  = 0;
    
    // Initialize timer control register
    CpuTimer0.RegsAddr->TCR.bit.TSS = 1;    // 1 = Stop, 0 = Start/Restart Timer
    CpuTimer0.RegsAddr->TCR.bit.TRB = 1;    // 1 = Reload Timer
    CpuTimer0.RegsAddr->TCR.bit.SOFT = 0;
    CpuTimer0.RegsAddr->TCR.bit.FREE = 0;   // Timer Free Run Disabled
    CpuTimer0.RegsAddr->TCR.bit.TIE = 1;    // 0 = Disable, 1 = Enable Interrupt
    
    // Reset __interrupt counter
    CpuTimer0.InterruptCount = 0;
    
    CpuTimer0Regs.TCR.all = 0x4001; // Use write-only instruction to clear TSS
    /////////////////////////////////
    IER |= M_INT1;
    
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;  // Enable TINT0 in the PIE: Group 1 __interrupt 7
    EINT;   // Enable Global __interrupt INTM
    ERTM;   // Enable Global realtime __interrupt DBGM
}
//_________________________________________________________________________________________________________________
void Timer0_Start(void)
{
   CpuTimer0Regs.TCR.bit.TSS = 0;
}
//_________________________________________________________________________________________________________________
void Timer0_Stop(void)
{
   CpuTimer0Regs.TCR.bit.TSS = 1;
}
//_________________________________________________________________________________________________________________
void Timer0_Reload(void)
{
    CpuTimer0Regs.TCR.bit.TRB = 1;
}
//_________________________________________________________________________________________________________________
Uint32 Timer0_Read(void)
{
    return CpuTimer0Regs.TIM.all;
}
//_________________________________________________________________________________________________________________
Uint32 Timer0_Read_Period(void)
{
    return CpuTimer0Regs.PRD.all;
}
//_________________________________________________________________________________________________________________








#endif /* TIMER0_H_ */
