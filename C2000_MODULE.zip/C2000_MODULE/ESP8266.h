#ifndef ANORA_WIFI_ESP8266_H_
#define ANORA_WIFI_ESP8266_H_




//
//
//#include "global.h"
//
//#define     LED_WIFI_GREEN_ON       (PORTH &= ~(1 << PH6))
//#define     LED_WIFI_GREEN_OFF      (PORTH |= (1 << PH6))
//
//#define     LED_WIFI_BLUE_ON         (PORTB &= ~(1 << PB4))
//#define     LED_WIFI_BLUE_OFF        (PORTB |= (1 << PB4))
//
//#define     LED_WIFI_RED_ON         (PORTH &= ~(1 << PH5))
//#define     LED_WIFI_RED_OFF         (PORTH |= (1 << PH5))
//
//#define     ESP_Power_Reset_PIN_HI  (PORTA |= (1 << PA6))
//#define     ESP_Power_Reset_PIN_LO  (PORTA &= ~(1 << PA6))
//
//#define     ESP_Hard_Reset_PIN_HI   (PORTA |= (1 << PA7))
//#define     ESP_Hard_Reset_PIN_LO   (PORTA &= ~(1 << PA7))
//
//
/////////////////////////////////////////////////////////////
// struct ESP8266
//{
//    unsigned char connected:1;
//    unsigned char present:1;
//    unsigned char command_received:1;
//
//    unsigned char bfr_rx[bfr_count_esp_rx];
//    unsigned char bfr_tx[bfr_count_esp_tx];
//
//    unsigned char channel;
//    unsigned char bfr_command[bfr_count_command];
//
//    volatile unsigned int bfr_ptr_rx;
//
//    unsigned char Display_Debug_message;
//
//};
/////////////////////////////////////////////////
//    void Read_wifi(unsigned char val);
//    void Init_ESP8266(void);
//    void flash_ESP8266(void);
//    void ESP8266_configure(void);
//    unsigned char Send_To_Wifi_Not_Success(const char * str_cmd,const char * str_reply, unsigned int delay_val);
//    void ESP8266_Handler(void);
//    void ESP_Send(unsigned char *bfr);
//    void ESP_Power_Reset(void);
//    void ESP_Hardware_Reset(void);
//
//
//
//
//
//




























#endif /* ANORA_WIFI_ESP8266_H_ */
