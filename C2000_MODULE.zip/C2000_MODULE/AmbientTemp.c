//#include "AmbientTemp.h"
//#include "BIOS2560.h"
//#include "Helper.h"
//#include "avr/io.h"
//#include "TEMP.h"
//
//		struct	Amb_temp		a_temp;
//extern	struct	Temperature   temp;
////_____________________________________________________________________________________________________________________________
//unsigned int Get_Ambient_Temperature(void)
//{
//	unsigned int i;
//	i=Get_ADC_Val(3);
//	//i=Get_ADC_Val(2);
//
//	i=(304.0/60.0)*i;
//	i= Get_Avj_val(i, &a_temp.avj_bfr[0],10);
//	//i-=50;
//	//a_temp.temp=temp.cell_Temp[23];
//	//a_temp.temp +=20;
//	a_temp.temp=i;
//
//	return a_temp.temp;
//}
////_____________________________________________________________________________________________________________________________
//void Get_Amb_Temp_Ascii(unsigned char *bfr)
//{
//	unsigned int i;
//
//	*bfr='A';bfr++;
//	*bfr='T';bfr++;
//	*bfr='=';bfr++;
////	i= temp.cell_Temp[23];
//	i=Get_Ambient_Temperature();
//	ConvertInt2Ascii(i,bfr,3,1);
//	bfr+=4;
//	*bfr='C';
//}
////_____________________________________________________________________________________________________________________________
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
