//#include <avr/io.h>
//#include "ESP8266.h"
//#include "Helper.h"
//#include "BIOS2560.h"
//#include "global.h"
//// To change baud rate in ESP8266 AT+UART_DEF=115200,8,1,0,0
////_______________________________________________________________________________________________________________________________________________________________________
//const __flash char esp_init[]  = "\r\nSystem is Going to Initialize ESP8266\r\n";
//////////////////////////////////
//const __flash char ATE0[]  = "ATE0\r\n";        // echo off, for on ATE1
//const __flash char ATE0_accepted[]  = "ATE0 Accepted\r\n";      // echo off, for on ATE1
//const __flash char ATE0_Not_accepted[]  = "ATE0 Not Accepted\r\n";      // echo off, for on ATE1
//
//const __flash char AT[]  = "AT\r\n";
//const __flash char AT_Accepted[]  = "AT Accepted \r\n";
//const __flash char AT_Not_Accepted[]  = "AT Not Accepted \r\n";
//
//
//const __flash char AT_plus_CWMODE_3[]  = "AT+CWMODE=3\r\n";
//const __flash char AT_plus_CWMODE_3_Accepted[]  = "AT+CWMODE=3 Accepted \r\n";
//const __flash char AT_plus_CWMODE_3_Not_Accepted[]  = "AT+CWMODE=3 Not Accepted\r\n";
//
//
//const __flash char AT_plus_RST[]  = "AT+RST\r\n";
//
//const __flash char AT_plus_CIPMUX_1[] = "AT+CIPMUX=1\r\n";
//const __flash char AT_plus_CIPMUX_1_Accepted[] = "AT+CIPMUX=1 Accepted \r\n";
//const __flash char AT_plus_CIPMUX_1_Not_Accepted[] = "AT+CIPMUX=1 not Accepted \r\n";
//
//const __flash char AT_plus_CIPSERVER_1_6000[]  = "AT+CIPSERVER=1,6000\r\n";
//const __flash char AT_plus_CIPSERVER_1_6000_accepted[]  = "AT+CIPSERVER=1,6000 accepted\r\n";
//const __flash char AT_plus_CIPSERVER_1_6000_not_accepted[]  = "AT+CIPSERVER=1,6000 not accepted\r\n";
////////////////////////////////////////////////
//const __flash char OK[] = "OK";
//const __flash char send_success[]  = "SEND OK";
//const __flash char send_error[]  = "SEND Not Success";
////////////////////////////////////////////////
//
//  //sudipc@chloridepower.co.in
//  //Sudip@123
//  //https://ccu.bookings.travelhouseindia.in/
//  // webmail password Sudi@1234
//
//const __flash char connect[] = "CONNECT";
//const __flash char closed[] = "CLOSED";
//const __flash char IPD[] = "+IPD";
//const __flash char HELO[] = "HELO";
//
//const __flash char data_received[]  = "Data Received";
//const __flash char helo_received[] = "HELO Received";
//const __flash char CIPSEND[] = "AT+CIPSEND=";
//const __flash char prompt[] = ">";
//const __flash char coma[] = ",";
//const __flash char colon[] = ":";
//const __flash char CR[] = "\r";
//const __flash char LF[] = "\n";
//const __flash char esp_init_success[] = "ESP8266 Initialize successfully....";
//
//const __flash char received_channel[] = "Received Channel=";
//
//
//const __flash char first_comma[] = "\r\nfirst_comma=";
//const __flash char second_comma[] = "second_comma=";
//const __flash char colon_position[] = "Colon Position=";
//const __flash char No_of_received_data[] = "No. Of Received Data=";
//const __flash char Received_Command[] = "Received Command=";
//
//const __flash char Sending_Data[] = "Sending Data....";
//const __flash char Prompt_Found[] = "Prompt Found";
//const __flash char Prompt_Not_Found[] = "Prompt Not Found";
//const __flash char tx_done[] = "Transmit Done. Exited";
////_______________________________________________________________________________________________________________________________________________________________________
//
//struct ESP8266      wifi;
////_______________________________________________________________________________________________________________________________________________________________________
//void Read_wifi(unsigned char val)
//{
//    wifi.bfr_rx[wifi.bfr_ptr_rx]=val;
//    wifi.bfr_ptr_rx++;
//}
////_______________________________________________________________________________________________________________________________________________________________________
//void Init_ESP8266(void)
//{
//    DDRB |=0b00010000;
//    DDRH |=0b01100000;
//    DDRA |=0b11000000;
//
//    //ESP_Hardware_Reset();
//    //ESP_Power_Reset();
//    ESP_Power_Reset_PIN_LO;
////  ESP_Hard_Reset_PIN_HI;
//    //ESP_Power_Reset_PIN_HI;
//    flash_ESP8266();
//    ESP8266_configure();
//    wifi.Display_Debug_message=true;
//}
////_________________________________________________________________________________________________________________________________________________________________
//void flash_ESP8266(void)
//{
//    wifi.present=false;
//    wifi.connected=false;
//
//    wifi.bfr_ptr_rx=0;
//    wifi.command_received=false;
//
//    Fill_Buffer(&wifi.bfr_rx[0],0, bfr_count_esp_rx);
//    Fill_Buffer(&wifi.bfr_tx[0],0, bfr_count_esp_tx);
//}
////_________________________________________________________________________________________________________________________________________________________________
//void ESP8266_configure(void)
//{
//    unsigned int i;
//    wifi.connected=false;
//    wifi.present=false;
//
//    LED_WIFI_GREEN_OFF;
//    LED_WIFI_BLUE_OFF;
//    LED_WIFI_RED_ON;
//
//    if(wifi.Display_Debug_message)  debug_print(esp_init);
//
//    //=== Send eCHO OFF==========================
//    i=0;
//    do{
//    if(Send_To_Wifi_Not_Success(ATE0,OK,100))
//    {
//        if(wifi.Display_Debug_message)  debug_print(ATE0_Not_accepted);
//        sleep(1000);
//        i++;
//        if(i>3)
//        {
//            //error_beep(3);
//            return;
//        }
//
//    }
//    else
//    {
//        if(wifi.Display_Debug_message)  debug_print(ATE0_accepted);
//        break;
//    }
//    }while(i<100);
//
//
//    //=====================================
////  sleep(10);
//
//    //=== Send AT==========================
//    if(Send_To_Wifi_Not_Success(AT,OK,1))
//    {
//        if(wifi.Display_Debug_message)  debug_print(AT_Not_Accepted);
//        return;
//    }
//    else
//    {
//        if(wifi.Display_Debug_message)  debug_print(AT_Accepted);
//    }
//    //=====================================
//
//
//
//    ////=== Send AT+RST======================
//    //if(Send_To_Wifi_Not_Success(AT_plus_RST,OK,100))
//    //{
//    //terminal.print_Two_String(AT_plus_RST,'>',send_error);
//    //return;
//    //}
//    //else
//    //{
//    //terminal.print_Two_String(AT_plus_RST,'>',send_success);
//    //}
//    ////=====================================
//
//
//
//    //=== Send AT_plus_CWMODE_3=============
//    if(Send_To_Wifi_Not_Success(AT_plus_CWMODE_3,OK,1))
//    {
//        if(wifi.Display_Debug_message)  debug_print(AT_plus_CWMODE_3_Not_Accepted);
//        return;
//    }
//    else
//    {
//        if(wifi.Display_Debug_message)  debug_print(AT_plus_CWMODE_3_Accepted);
//    }
//    //=====================================
//    sleep(50);
//
//
//    //=== Send AT_plus_CIPMUX_1=============
//    if(Send_To_Wifi_Not_Success(AT_plus_CIPMUX_1,OK,1))
//    {
//        if(wifi.Display_Debug_message)  debug_print(AT_plus_CIPMUX_1_Not_Accepted);
//        return;
//    }
//    else
//    {
//        if(wifi.Display_Debug_message)  debug_print(AT_plus_CIPMUX_1_Accepted);
//    }
//    //=====================================
//
//    //=== Send AT_plus_CIPSERVER_1_6000=============
//    if(Send_To_Wifi_Not_Success(AT_plus_CIPSERVER_1_6000,OK,10))
//    {
//        if(wifi.Display_Debug_message)  debug_print(AT_plus_CIPSERVER_1_6000_not_accepted);
//        return;
//    }
//    else
//    {
//        if(wifi.Display_Debug_message)  debug_print(AT_plus_CIPSERVER_1_6000_accepted);
//    }
//    //=====================================
////  sleep(1000);
//
//    //flush();
//    //s.bfr_tx[0]='A';
//    //s.bfr_tx[1]='T';
//    //s.bfr_tx[2]='+';
//    //s.bfr_tx[3]='C';
//    //s.bfr_tx[4]='I';
//    //s.bfr_tx[5]='F';
//    //s.bfr_tx[6]='S';
//    //s.bfr_tx[7]='R';
//    //send_2_Esp(&s.bfr_tx);
//    //_delay_ms(2000);
//    //Send_2_Terminal(&s.bfr_rx);
//
//    debug_print(esp_init_success);
//    flash_ESP8266();
//
//    wifi.present=true;
//    wifi.connected=false;
//
//    LED_WIFI_RED_OFF;
//    LED_WIFI_GREEN_OFF;
//    LED_WIFI_BLUE_ON;
//    return;
//}
////_____________________________________________________________________________________________________________________________________________________
//
//
//
////_____________________________________________________________________________________________________________________________________________________
//void ESP8266_Handler(void)
//{
//        sleep(5);
//        wifi.bfr_ptr_rx=0;
//        puts_2_serial0(&wifi.bfr_rx[0]);
//
//        ///////////////////////////////////////
//        if(String_found_in_bfr(IPD,&wifi.bfr_rx[0],bfr_count_esp_rx,0))
//        {
//            wifi.channel=wifi.bfr_rx[7];
//
//            int fast_coma=Index_Of(coma,&wifi.bfr_rx[0],bfr_count_esp_rx,0);
//        //  debug_print(first_comma);debug_print_Int(fast_coma);
//
//            int second_coma=Index_Of(coma,&wifi.bfr_rx[0],bfr_count_esp_rx,fast_coma+1);
//        //  debug_print(second_comma);debug_print_Int(second_coma);
//
//            int colon_count=Index_Of(colon,&wifi.bfr_rx[0],bfr_count_esp_rx,second_coma);
//        //  debug_print(colon_position);debug_print_Int(colon_count);
//
//            int digit_count=ConvertAscii2Decimal(&wifi.bfr_rx[second_coma],colon_count-1-second_coma,0);
//        //  debug_print(No_of_received_data);debug_print_Int(digit_count);
//
//            Fill_Buffer(&wifi.bfr_command[0],0,bfr_count_command);
//            Copyram2ram(&wifi.bfr_rx[colon_count],&wifi.bfr_command[0],digit_count);
//            if(wifi.Display_Debug_message)  debug_print(Received_Command);
//            if(wifi.Display_Debug_message)  puts_2_serial0(&wifi.bfr_command[0]);
//            wifi.command_received=true;
//        }
//        else if(String_found_in_bfr(connect,&wifi.bfr_rx[0],bfr_count_esp_rx,0))
//        {
//            wifi.connected=true;
//            LED_WIFI_BLUE_OFF;
//            LED_WIFI_GREEN_ON;
//            flash_ESP8266();
//        }
//        else if(String_found_in_bfr(closed,&wifi.bfr_rx[0],bfr_count_esp_rx,0))
//         {
//             wifi.connected=false;
//             LED_WIFI_BLUE_ON;
//             LED_WIFI_GREEN_OFF;
//             flash_ESP8266();
//         }
//         ///////////////////////////////////////
//
//}
////////______________________________________________________________________________________________________________________________________________________
//unsigned char Send_To_Wifi_Not_Success(const char * str_cmd,const char * str_reply, unsigned int delay_val)
//{
//    flash_ESP8266();
//    pgm2ram(str_cmd, &wifi.bfr_tx[0]);
//    puts_2_serial(ESP_Serial_port, &wifi.bfr_tx[0]);
//    sleep(delay_val);
//
//    if(wifi.Display_Debug_message)  puts_2_serial0(&wifi.bfr_rx[0]);
//
//    if(String_found_in_bfr(str_reply,&wifi.bfr_rx[0],bfr_count_esp_rx,0))
//    {
//        return false;
//    }
//    else
//    {
//        return true;
//    }
//}
////________________________________________________________________________________________________________________________________________________________
// void ESP_Send(unsigned char *bfr)
// {
//    unsigned char tx[20];
////  debug_print(Sending_Data);
//
//    Fill_Buffer(&tx[0],0,20);
//    flash_ESP8266();
//
//    pgm2ram(CIPSEND, &tx[0]);       // "AT+CIPSEND="
//    tx[11]=wifi.channel;
//    tx[12]=',';
// ////////////////////////////////////
// int cmd_length=Get_length(bfr);
//
// if(cmd_length>99)
// {
//    ConvertInt2Ascii(cmd_length,&tx[13],3,0);
//    tx[16]='\r';
//    tx[17]='\n';
// }
// else if(cmd_length>9)
// {
//    ConvertInt2Ascii(cmd_length,&tx[13],2,0);
//    tx[15]='\r';
//    tx[16]='\n';
// }
// else
// {
//    ConvertInt2Ascii(cmd_length,&tx[13],1,0);
//    tx[14]='\r';
//    tx[15]='\n';
// }
// /////////////////////////////
//// puts_2_serial0(&tx[0]);
// puts_2_serial(ESP_Serial_port,&tx[0]);
//
// sleep(2);
// //puts_2_serial0(&wifi.bfr_rx[0]);
//
// if(String_found_in_bfr(prompt,&wifi.bfr_rx[0],bfr_count_esp_rx,0))
// {
////  debug_print(Prompt_Found);
//    puts_2_serial(ESP_Serial_port,&bfr[0]);
// }
// else
// {
////  debug_print(Prompt_Not_Found);
// }
////  sleep(10);
////  puts_2_serial0(&wifi.bfr_rx[0]);
//    if(wifi.Display_Debug_message)  debug_print(tx_done);
//    flash_ESP8266();
//    return;
// }
////________________________________________________________________________________________________________________________________________________________
//void ESP_Power_Reset(void)
//{
//    ESP_Power_Reset_PIN_HI;
//    sleep(1000);
//    ESP_Power_Reset_PIN_LO;
//    sleep(1000);
//}
////________________________________________________________________________________________________________________________________________________________
//void ESP_Hardware_Reset(void)
//{
//    ESP_Hard_Reset_PIN_LO;
//    sleep(100);
//    ESP_Hard_Reset_PIN_HI;
//    sleep(100);
//
//
//}
////________________________________________________________________________________________________________________________________________________________
//unsigned char Init_ESP8266_Client(void)
//{
//
//
//
//
//
//}
////___________________________________________________________________________________________________________________________________
////void Send_Wifi_Id_Password(void)
////{
////  unsigned int i,j;
////  unsigned char count,total;
////
////  Fill_Buffer(&wifi.bfr_data,0x00,30);
////  flash();
////
////  Send_Cmd_To_ESP8266("AT+CWSAP?",10000);
////
////  i=Find_And_Get_Position(":");                   // 0x22= "(double quote)
////  j=Find_And_Get_Next_Pos(i,",");
////  count= ((j-2)-(i+1));
////
////
////  wifi.bfr_data[0]='<';
////  Copyram2ram(&com.bfr[i+1],&wifi.bfr_data[1],count);
////
////  count++;
////  wifi.bfr_data[count]='#';
////  count++;
////  total=count;
////
////  i=j;
////  j=Find_And_Get_Next_Pos(i,",");
////  count= ((j-2)-(i+1));
////
////  if(count!=0)
////  {
////      Copyram2ram(&com.bfr[i+1],&wifi.bfr_data[total],count);
////  }
////  total+=count;
////
////  wifi.bfr_data[total]='>';
////  total++;
////  //////////////////////////
////  flash();
////  Fill_Buffer(&wifi.bfr_To_Send,0, esp_bfr_count);
////  strcpypgm2ram(&wifi.bfr_To_Send,"AT+CIPSEND=X,X");  //chanel, data <99.678>
////  wifi.bfr_To_Send[11]=wifi.channel;
////
////  if(total<=9)
////  ConvertInt2Ascii(total,&wifi.bfr_To_Send[13],1,0);
////  else ConvertInt2Ascii(total,&wifi.bfr_To_Send[13],2,0);
////
////  send_cmd(&wifi.bfr_To_Send);
////  sleep(40);
////  if(found_in_comm_bfr(">"))
////      {
////          send_cmd_Without_Linefeed(&wifi.bfr_data);
////          sleep(10000);
////          if(found_in_comm_bfr("SEND OK"))
////          {
////              flash();
////              return;
////          }
////      }
////  else
////      {
////          flash();
////      }
////}
//////------------------------------------------------
////void Set_Wifi_Id_Password(void)
////{
////  unsigned char i,j,count,total;
////
////  // set time out
////  Fill_Buffer(&wifi.bfr_To_Send,0, esp_bfr_count);
////  strcpypgm2ram(&wifi.bfr_To_Send,"AT+CWSAP=");   //chanel, data <99.678>
////  wifi.bfr_To_Send[9]='"';
////
////  i=Find_And_Get_Position("#");                   // 0x22= "(double quote)
////  j=Find_And_Get_Next_Pos(i,"#");
////  count= ((j-1)-i);
////  Copyram2ram(&com.bfr[i],&wifi.bfr_To_Send[10],count);
////
////  total=10+count;
////  wifi.bfr_To_Send[total]='"';
////  total++;
////  wifi.bfr_To_Send[total]=',';
////  total++;
////  wifi.bfr_To_Send[total]='"';
////  total++;
////
////  i=Find_And_Get_Next_Pos(i,">");                 // 0x22= "(double quote)
////
////  count= ((i-1)-j);
////  Copyram2ram(&com.bfr[j],&wifi.bfr_To_Send[total],count);
////
////  total +=count;
////
////  wifi.bfr_To_Send[total]='"';
////  total++;
////
////  wifi.bfr_To_Send[total]=',';
////  total++;
////
////  wifi.bfr_To_Send[total]='1';//wifi.channel;
////  total++;
////
////  wifi.bfr_To_Send[total]=',';
////  total++;
////
////  wifi.bfr_To_Send[total]='3';
////  total++;
////
////  wifi.bfr_To_Send[total]=NULL;
////
////  flash();
////  send_cmd(&wifi.bfr_To_Send);
////  sleep(1000);
////  if(found_in_comm_bfr("OK"))
////      {
////           Send_OK();
////      }
////}
//////------------------------------------------------
////void set_default_SSID_Password(void)
////{
////  unsigned int i;
//////    i=0;
//////    Init_ESP8266();
////
//////    flash();
//////    Fill_Buffer(&wifi.bfr_To_Send,0, esp_bfr_count);
//////    strcpypgm2ram(&wifi.bfr_To_Send,"AT+CWSAP?");   //chanel, data <99.678>
//////    flash();
//////    send_cmd(&wifi.bfr_To_Send);
//////    sleep(10000);
////
////  i=0;
////  Fill_Buffer(&wifi.bfr_To_Send,0, esp_bfr_count);
////  strcpypgm2ram(&wifi.bfr_To_Send,"AT+CWSAP=#pces#,#pces@1234#,1,3"); //chanel, data <99.678>
////  Replace_Hash_To_Double_Quotation(&wifi.bfr_To_Send);
////
////  flash();
////  send_cmd(&wifi.bfr_To_Send);
////  sleep(10000);
////}
//////------------------------------------------------
