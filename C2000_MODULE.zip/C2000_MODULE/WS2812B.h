


#define     LED_COUNT   178
//_______________________________________________________________________________________________________________________
struct RGB_LED
{
    unsigned char R;
    unsigned char G;
    unsigned char B;
};
//_______________________________________________________________________________________________________________________
void WS2812B_Init(void);
void WS2812B_PIN_Test(void);
void WS2812B_Update_LED(unsigned int index, unsigned char R,unsigned char G, unsigned char B);
void WS2812B_Fill(unsigned char R,unsigned char G,unsigned char B);
void WS2812B_update(void);
void WS2812B_Send_Single_RGB_LED(unsigned char LED_R,unsigned char LED_G, unsigned char LED_B);
void WS2812B_send_Bit_1(void);
void WS2812B_send_Bit_0(void);


