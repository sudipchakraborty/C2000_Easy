/*
 * Heartbit.h
 *
 *  Created on: 24-Feb-2022
 *      Author: chand
 */

#ifndef ANORA_LED_HEARTBIT_HEARTBIT_H_
#define ANORA_LED_HEARTBIT_HEARTBIT_H_
//////////////////////////////////////////
struct str_Heartbit
{
    long delay_reg;
    unsigned char state;
};
///////////////////////////////////////
void Heartbit_LED_Init(void);
void Blink_Heartbit_LED(void);





#endif /* ANORA_LED_HEARTBIT_HEARTBIT_H_ */
