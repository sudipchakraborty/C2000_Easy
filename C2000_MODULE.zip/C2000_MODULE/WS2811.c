#include "WS2811.h"
#include "F2805x_Cla_typedefs.h"    // F2806x CLA Type definitions
#include "F2805x_Device.h"          // F2805x Headerfile Include File

#define WS2811_LED_PIN_HI       GpioDataRegs.GPASET.bit.GPIO1=1
#define WS2811_LED_PIN_LO       GpioDataRegs.GPACLEAR.bit.GPIO1=1
#define WS2811_LED_PIN_As_Out   GpioCtrlRegs.GPADIR.bit.GPIO1= 1
//_____________________________________________________________________________________________________________________
struct WS2811_RGB_LED      WS2811_rgb[WS2811_LED_COUNT];
//struct WS2811_RGB_LED      bfr_rotate[4];
//___________________________________________________________________________________________________________
void WS2811_Init(void)
{
    EALLOW;
        WS2811_LED_PIN_As_Out;
    EDIS;

 //   bfr_rotate

}
//_______________________________________________________________________________________________________
void WS2811_PIN_Test(void)
{
    WS2811_LED_PIN_HI;
    WS2811_LED_PIN_LO;
}
//___________________________________________________________________________________________________________________________________________________
void WS2811_Action_from_Command(unsigned char *packet)
{
    unsigned char index,R,G,B;

    unsigned char i;
    if(*(packet+1)=='U')    // index update <U001#123,100,102>
    {
        index=ConvertAscii2Byte(packet+2);
        R=ConvertAscii2Byte(packet+6);
        G=ConvertAscii2Byte(packet+10);
        B=ConvertAscii2Byte(packet+14);
        WS2811_Update_LED(index,R,G,B);
       // WS2812B_update();
    }
    else if(*(packet+1)=='D')  // display <D>>
    {
        WS2811_update();
    }
    else if(*(packet+1)=='F')  //  <F,123,100,102>\r
    {
       R=ConvertAscii2Byte(packet+3);
       G=ConvertAscii2Byte(packet+7);
       B=ConvertAscii2Byte(packet+11);
       WS2811_Fill(R,G,B);
       WS2811_update();
    }
    else
    {

    }
}
void WS2811_Update_LED(unsigned int index, unsigned char R,unsigned char G, unsigned char B)
{
    WS2811_rgb[index].R=R;
    WS2811_rgb[index].G=G;
    WS2811_rgb[index].B=B;
}
//___________________________________________________________________________________________________________________________________________________
void Fill_And_Update(unsigned char R,unsigned char G,unsigned char B)
{
    WS2811_Fill(R,G,B);
    WS2811_update();
}
//___________________________________________________________________________________________________________________________________________________
void WS2811_Fill(unsigned char R,unsigned char G,unsigned char B)
{
    unsigned int i;

     for(i=0;i<WS2811_LED_COUNT;i++)
     {
         WS2811_rgb[i].R=R;
         WS2811_rgb[i].G=G;
         WS2811_rgb[i].B=B;
     }
}
//___________________________________________________________________________________________________________________________________________________
void WS2811_update(void)
{
    unsigned int i;

     for(i=0;i<WS2811_LED_COUNT;i++)
     {
         WS2811_Send_Single_RGB_LED(WS2811_rgb[i].R,WS2811_rgb[i].G, WS2811_rgb[i].B);
     }
}
//__________________________________________________________________________________________________________
void WS2811_Send_Single_RGB_LED(unsigned char LED_R,unsigned char LED_G, unsigned char LED_B)
{
    register unsigned char i,val;

    val=LED_G;    //G

       for(i=0;i<8;i++)
       {
           if((val &0x80)==0)
           {
               WS2811_send_Bit_0();
           }
           else
           {
               WS2811_send_Bit_1();
           }
           val=val<<1;
      }
    //////////////////////////////////////
    val=LED_R;

    for(i=0;i<8;i++)
    {
        if((val &0x80)==0)
        {
            WS2811_send_Bit_0();                                                                                                         ;
        }
        else
        {
            WS2811_send_Bit_1();
        }

        val=val<<1;
    }
    ////////////////////////////////////
    val=LED_B;    // B

    for(i=0;i<8;i++)
    {
        if((val &0x80)==0)
        {
            WS2811_send_Bit_0();
        }
        else
        {
            WS2811_send_Bit_1();
        }

        val=val<<1;
    }
}
//_________________________________________________________________________________________________________
void WS2811_send_Bit_1(void)
{
// send T1H=1.2us
    WS2811_LED_PIN_HI;
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");

                        __asm("   NOP");
                        __asm("   NOP");
                        __asm("   NOP");

   // send T1L=1.3us
    WS2811_LED_PIN_LO;
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
}
//__________________________________________________________________________________________________________
void WS2811_send_Bit_0(void)
{
    // send T0H= 0.5us
    WS2811_LED_PIN_HI;
    __asm("   NOP");
//  send T0L= 2.0us
    WS2811_LED_PIN_LO;
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
}
//______________________________________________________________________________________________________________
