#include "DSP28x_Project.h"
#include "I2C_Software.h"
#include "io.h"

unsigned char I2C_Soft_SCL_PIN;
unsigned char I2C_Soft_SDA_PIN;

#define SDA_Hi    GpioDataRegs.GPBDAT.bit.GPIO32=1
#define SDA_Lo    GpioDataRegs.GPBDAT.bit.GPIO32=0
#define SDA_Read  GpioDataRegs.GPBDAT.bit.GPIO32
#define SDA_In    GpioCtrlRegs.GPBDIR.bit.GPIO32=set_as_In
#define SDA_Out   GpioCtrlRegs.GPBDIR.bit.GPIO32=set_as_out

#define SCL_Hi    GpioDataRegs.GPBDAT.bit.GPIO33=1
#define SCL_Lo    GpioDataRegs.GPBDAT.bit.GPIO33=0
#define SCL_Out   GpioCtrlRegs.GPBDIR.bit.GPIO33=set_as_out
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Init(void)
 {
    EALLOW; SDA_Out; EDIS;
    EALLOW; SCL_Out; EDIS;

    SDA_Hi;
    SCL_Hi;
 }
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Test_SCL_PIN(void)
{
    SCL_Hi;
    I2C_Soft_delay();
    SCL_Lo;
    I2C_Soft_delay();
}
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Test_SDA_As_Output(void)
{
    EALLOW; SDA_Out;  EDIS;

    SDA_Hi;
    I2C_Soft_delay();
    SDA_Lo;
    I2C_Soft_delay();
}
//_________________________________________________________________________________________________________________________________________
unsigned char I2C_Soft_Test_SDA_As_Input(void)
{
    EALLOW; SDA_In; EDIS;
    return SDA_Read;
}
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Start(void)
{

    //  SCL_Lo;
        SDA_Hi;
     //       I2C_Soft_delay();
        SCL_Hi;
            I2C_Soft_delay();
        SDA_Lo;
            I2C_Soft_delay();
        SCL_Lo;

    //////////////////////
//  //  SCL_Lo;
//    SDA_Hi;
//        I2C_Soft_delay();
//    SCL_Hi;
//        I2C_Soft_delay();
//    SDA_Lo;
//        I2C_Soft_delay();
//    SCL_Lo;
}
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Stop(void)
{

  //  SCL_Lo;
  //    I2C_Soft_delay();
 //    SDA_Lo;
 //     I2C_Soft_delay();
    SCL_Hi;
      I2C_Soft_delay();
    SDA_Hi;


//  SCL_Lo;
//    I2C_Soft_delay();
//   SDA_Lo;
//    I2C_Soft_delay();
//  SCL_Hi;
//    I2C_Soft_delay();
//  SDA_Hi;
}
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Ack(void)
{
  SDA_Lo;               //Pull SDA low to indicate Positive ACK
    I2C_Soft_Clock();   //Generate the Clock
  SDA_Hi;               // Pull SDA back to High(IDLE state)
}
//_________________________________________________________________________________________________________________________________________
unsigned char I2C_Soft_Ack_Received(void)
{
    unsigned char i;

     EALLOW; SDA_In; EDIS;
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
 //    I2C_Soft_delay();

     SCL_Hi;              //Pull SDA low to indicate Positive ACK
     I2C_Soft_delay();
     i=SDA_Read;
     SCL_Lo;
     EALLOW; SDA_Out; EDIS;
    I2C_Soft_delay();

    return i;
}
//_________________________________________________________________________________________________________________________________________




void I2C_Soft_NoAck(void)
{
  SDA_Hi;               //Pull SDA high to indicate Negative/NO ACK
       I2C_Soft_Clock();// Generate the Clock
  SCL_Hi;               // Set SCL
}
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Write(unsigned char v_i2cData_u8)
{
    unsigned char i;

    for(i=0;i<8;i++)
      {
          if(v_i2cData_u8 & 0x80) SDA_Hi;
          else SDA_Lo;
          I2C_Soft_Clock();
          v_i2cData_u8 = v_i2cData_u8<<1;
      }
   //   I2C_Soft_Clock();

//    for(i=0;i<8;i++)
//    {
//        if(v_i2cData_u8 & 0x80) SDA_Hi;
//        else SDA_Lo;
//        I2C_Soft_Clock();
//        v_i2cData_u8 = v_i2cData_u8<<1;
//    }
//    I2C_Soft_Clock();
}
//_________________________________________________________________________________________________________________________________________
unsigned char I2C_Soft_Read(unsigned char v_ackOption_u8)
{
    unsigned char i, v_i2cData_u8=0x00;

    EALLOW; SDA_In; EDIS;
    I2C_Soft_delay();

    for(i=0;i<8;i++)
    {
        I2C_Soft_delay();
        SCL_Hi;
        I2C_Soft_delay();

        v_i2cData_u8 = v_i2cData_u8<<1;
        v_i2cData_u8 |=SDA_Read;

        SCL_Lo;
    }
    if(v_ackOption_u8==1)
    {
        I2C_Soft_Ack();
    }
    else
    {
        I2C_Soft_NoAck();
    }

    EALLOW; SDA_Out; EDIS;

    return v_i2cData_u8;                    // Finally return the received Byte*
}
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Clock(void)
{
    I2C_Soft_delay();
    SCL_Hi;
    I2C_Soft_delay();
    SCL_Lo;
}
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_delay(void)
{
    unsigned int i;

   // for(i=0;i<=100;i++);
 //   return;

    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");
    __asm("   NOP");

    __asm("   NOP");
       __asm("   NOP");
       __asm("   NOP");
       __asm("   NOP");
       __asm("   NOP");
       __asm("   NOP");
       __asm("   NOP");
       __asm("   NOP");
       __asm("   NOP");
       __asm("   NOP");

}
//_________________________________________________________________________________________________________________________________________
void I2C_Soft_Set_BUS_As_Input(void)
{
    EALLOW;
        GpioCtrlRegs.GPBDIR.bit.GPIO32=set_as_In;
        GpioCtrlRegs.GPBDIR.bit.GPIO33=set_as_In;
    EDIS;
}
//_________________________________________________________________________________________________________________________________________
