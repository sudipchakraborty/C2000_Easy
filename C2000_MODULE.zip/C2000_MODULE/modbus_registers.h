#ifndef MODBUS_REGISTERS_H_
#define MODBUS_REGISTERS_H_

enum 
{
	Modbus_Manufacturer			=0x0000,
	Modbus_LOCATION				=0x000A,
	Modbus_DEVICE_ID			=0x0014,
	Modbus_DEVICE_TYPE			=0x0019,
	Modbus_SERIAL_NUMBER		=0x001E,
	Modbus_FW_VERSION			=0x0023,
	Modbus_HW_VERSION			=0x0028,
	
	// Register block for Digital Input
	Modbus_ID                   =0x0065,
	Modbus_FAULT                =0x0066,
	Modbus_EXT_DIGITAL_IN	    =0x0067,
	Modbus_BUS_I_OC             =0x0068,
    Modbus_PHASE_I_OC           =0x0069,
    Modbus_Temperature_1        =0x006A,
    Modbus_Temperature_2        =0x006B,
    Modbus_Temperature_3        =0x006C,
    Modbus_U5_GAIN_Select       =0x006D,
    Modbus_U6_GAIN_Select       =0x006E,

    // Register Block for Digital Output
    Modbus_GATE_HB1_HS          =0x00C8,
    Modbus_GATE_HB1_LS          =0x00C9,
    Modbus_GATE_HB2_HS          =0x00CA,
    Modbus_GATE_HB2_LS          =0x00CB,
    Modbus_GATE_HB3_HS          =0x00CC,
    Modbus_GATE_HB3_LS          =0x00CD,
    Modbus_FAN_CONTROL          =0x00CE,
    Modbus_PWM_ENABLE           =0x00CF,
    Modbus_EXT_DIGITAL_OUT0     =0x00D0,
    Modbus_EXT_DIGITAL_OUT1     =0x00D1,

    // Register Block for Analog Input
    Modbus_I_PHASE_SNS          =0x012C,
    Modbus_VREMOTE_SNS          =0x012E,
    Modbus_VBUS_SNS             =0x0130,
    Modbus_VPHASE_SNS           =0x0132,
    Modbus_I_BUS_SNS            =0x0134,
    ////////////////////////////////////
	};
	

#endif /* MODBUS_REGISTERS_H_ */
