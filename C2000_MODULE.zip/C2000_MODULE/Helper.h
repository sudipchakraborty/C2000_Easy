


unsigned char ConvertAscii2Byte(unsigned char *srcptr);

//
// void ConvertInt2Ascii(unsigned int val,unsigned char *destptr,unsigned char digitcount,unsigned char DecimalPlace);
// void Fill_Buffer(unsigned char *srcptr,unsigned char data, unsigned int count);
// void ConvertByte2Ascii(unsigned char val,unsigned char *destptr,unsigned char digitcount,unsigned char DecimalPlace);
// unsigned int ConvertAscii2Decimal(unsigned char *srcptr,unsigned char count, unsigned char DecimalPlace);
// void Copyram2ram( unsigned char *src,unsigned char *dest, unsigned int count);
// unsigned char CompareRam2Ram_OK(unsigned char *cmpptr1, unsigned char *cpmptr2,unsigned char count);
// unsigned char Get_length(unsigned char *bfr);
//unsigned int Get_Uint16_From_Byte(unsigned char Hi_Byte, unsigned char Lo_Byte);
//int Get_int16_From_Byte(unsigned char Hi_Byte, unsigned char Lo_Byte);
//void Get_Bytes_From_Uint16(unsigned int val, unsigned char *bfr);
//void Get_Bytes_From_int16(int val, unsigned char *bfr);
//unsigned char str_count(unsigned char *src_bfr, unsigned char bfr_count);
//void Replace_Hash_To_Double_Quotation(unsigned char *bfr);
//void ConvertBCD2Ascii(unsigned char val, unsigned char *destptr);
//unsigned char ConvertBCD2Decimal(unsigned char val);
//unsigned char ConvertAscii2BCD(unsigned char *srcptr);
//
//unsigned char String_found_in_bfr(const char * str, unsigned char *bfr, unsigned char bfr_count, unsigned char StartIndex);
//unsigned char Index_Of(const char * str, unsigned char *bfr, unsigned int bfr_count, unsigned char StartIndex);
//
//
//void ConvertUnsignedLong2Ascii(unsigned long val, unsigned char *destptr);
//unsigned int Get_Avj_val(unsigned int val, unsigned int *bfr,unsigned char bfr_count);
//
//
//void convert_long_to_byte(long val, unsigned char *bfr);
//long convert_byte_to_long(unsigned char *bfr);
//unsigned long Convert_Ascii_2_long(unsigned char *destptr, unsigned char digit_count);
