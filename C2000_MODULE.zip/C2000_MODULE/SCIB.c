#include "SCIB.h"

#include "F2805x_Cla_typedefs.h"    // F2806x CLA Type definitions
#include "F2805x_Device.h"          // F2805x Headerfile Include File

interrupt void scibTxFifoIsr(void);
interrupt void scibRxFifoIsr(void);

struct str_SCIB       SerialB;
//_______________________________________________________________________________________________________________________
void SCIB_Config(long baud_rate)
{
    sciB_Port_Config();
    DINT;
    sciB_Module_config();
    sciB_Interrupt_Config();
    SCIB_Set_Baud_Rate(baud_rate);
    SCIB_set_RX();
    SCIB_Purge();
}
//_______________________________________________________________________________________________________________________
void sciB_Interrupt_Config(void)
{
    EALLOW;  // This is needed to write to EALLOW protected registers
        PieVectTable.SCIRXINTB = &scibRxFifoIsr;
        PieVectTable.SCITXINTB = &scibTxFifoIsr;
    EDIS;   // This is needed to disable write to EALLOW protected registers

    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   // Enable the PIE block
    PieCtrlRegs.PIEIER9.bit.INTx3= 1;     // PIE Group 9, INT1
    PieCtrlRegs.PIEIER9.bit.INTx4= 1;     // PIE Group 9, INT2

    IER = 0x100; // Enable CPU INT

    EINT;
}
//_______________________________________________________________________________________________________________________
void sciB_Port_Config(void)
{
    EALLOW;
            GpioCtrlRegs.GPAPUD.bit.GPIO23 = 0;  // Enable pull-up for GPIO23 (SCIRXDB)
            GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;  // Enable pull-up for GPIO14 (SCITXDB)

            GpioCtrlRegs.GPAQSEL2.bit.GPIO23 = 3;   // Asynch input GPIO23 (SCIRXDB)

            GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 3;       // Configure GPIO23 for SCIRXDB
            GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 2;       // Configure GPIO14 for SCITXDB
    EDIS;


    EALLOW;
          GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 0;
          GpioCtrlRegs.GPADIR.bit.GPIO10 = 1;
    EDIS;
}
//_______________________________________________________________________________________________________________________
void sciB_Module_config(void)
{
    ScibRegs.SCICCR.all = 0x0007;           // 1 stop bit,  No loopback,No parity,8 char bits, async mode, idle-line protocol
    ScibRegs.SCICTL1.all = 0x0003;          // enable TX, RX, internal SCICLK, Disable RX ERR, SLEEP, TXWAKE
    ScibRegs.SCICTL2.bit.TXINTENA = 1;
    ScibRegs.SCICTL2.bit.RXBKINTENA = 1;
    ScibRegs.SCICCR.bit.LOOPBKENA =0;       // 1; // Enable loop back
    ScibRegs.SCIFFTX.all = 0xC022;
    ScibRegs.SCIFFRX.all = 0x0022;
    ScibRegs.SCIFFCT.all = 0x00;

    ScibRegs.SCICTL1.all = 0x0023;          // Relinquish SCI from Reset
    // SciaRegs.SCIFFTX.bit.TXFIFOXRESET = 1;
    ScibRegs.SCIFFRX.bit.RXFIFORESET = 1;
}
//_______________________________________________________________________________________________________________________
interrupt void scibTxFifoIsr(void)
{
    if(SerialB.scib_bfr_ptr_tx<SerialB.scib_tx_count+1)
    {
        ScibRegs.SCITXBUF=SerialB.scib_bfr_tx[SerialB.scib_bfr_ptr_tx];
        SerialB.scib_bfr_ptr_tx++;
        ScibRegs.SCITXBUF=SerialB.scib_bfr_tx[SerialB.scib_bfr_ptr_tx];
        SerialB.scib_bfr_ptr_tx++;
    }
    else
    {
        ScibRegs.SCIFFTX.bit.TXFIFOXRESET =0;
        SCIB_set_RX();
    }
    ScibRegs.SCIFFTX.bit.TXFFINTCLR = 1;  // Clear SCI Interrupt flag
    PieCtrlRegs.PIEACK.all |= 0x100;      // Issue PIE ACK
}
//_______________________________________________________________________________________________________________________
interrupt void scibRxFifoIsr(void)
{
    SerialB.scib_bfr_rx[SerialB.scib_bfr_ptr_rx] = ScibRegs.SCIRXBUF.all;        // Read data
    if(SerialB.scib_bfr_ptr_rx<scib_bfr_count)  SerialB.scib_bfr_ptr_rx++;
    SerialB.scib_bfr_rx[SerialB.scib_bfr_ptr_rx] = ScibRegs.SCIRXBUF.all;        // Read data
    if(SerialB.scib_bfr_ptr_rx<scib_bfr_count)  SerialB.scib_bfr_ptr_rx++;

    ScibRegs.SCIFFRX.bit.RXFFOVRCLR = 1;   // Clear Overflow flag
    ScibRegs.SCIFFRX.bit.RXFFINTCLR = 1;   // Clear Interrupt flag

    PieCtrlRegs.PIEACK.all |= 0x100;       // Issue PIE ack
}

unsigned char sciB_Data_Received_End_Char(unsigned char c)
{
    if(SerialB.scib_bfr_rx[SerialB.scib_bfr_ptr_rx]=='>')
        return -1;
    else
        return 0;
}
//_______________________________________________________________________________________________________________________
unsigned char sciB_Data_Received(void)
{
    unsigned int i;
    if(SerialB.scib_bfr_ptr_rx>0)
    {
        for(i=0;i<2000;i++);
        return -1;
    }
    else
    {
        return 0;
    }
}
//_______________________________________________________________________________________________________________________
void scib_send(unsigned char *bfr, unsigned int count)
{
    unsigned char i;
    double delay_reg;

    SCIB_set_TX();

    for(i=0;i<count;i++)
    {
        SerialB.scib_bfr_tx[i]= *bfr;
        bfr++;
    }
    SerialB.scib_bfr_ptr_tx=0;
    SerialB.scib_tx_count=count;
    ScibRegs.SCIFFTX.bit.TXFIFOXRESET = 1;

    for(delay_reg=0;delay_reg<count*40;delay_reg++);
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIB_Set_Baud_Rate(long baud_rate)
{
    switch(baud_rate)
    {
        case 9600:      ScibRegs.SCILBAUD=0x00C2;   break;
        case 19200:     ScibRegs.SCILBAUD=0x0061;   break;
        case 38400:     ScibRegs.SCILBAUD=0x0030;   break;
        case 115200:    ScibRegs.SCILBAUD=15;       break;
        default:        ScibRegs.SCILBAUD=0x00C2;   break;
    }
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIB_Purge(void)
{
    unsigned int i;

    SerialB.scib_bfr_ptr_rx=0;
    SerialB.scib_bfr_ptr_tx=0;

    for(i=0;i<scib_bfr_count;i++)
    {
        SerialB.scib_bfr_tx[i]=0x00;
        SerialB.scib_bfr_rx[i]=0x00;
    }

//    SciaRegs.SCIFFRX.bit.RXFFST=0;
//    SerialA.ptr_rx=0;
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIB_RE_DE_Test(void)
{
    unsigned int i;

    SCIB_set_TX();
    for(i=0;i<10000;i++);
    SCIB_set_RX();
    for(i=0;i<10000;i++);
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIB_set_TX(void)
{
    unsigned int i;
 //   for(i=0;i<1000;i++);
    GpioDataRegs.GPASET.bit.GPIO10= 1;
 //   for(i=0;i<1000;i++);
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIB_set_RX(void)
{
    unsigned int i;
    for(i=0;i<1000;i++);
    GpioDataRegs.GPACLEAR.bit.GPIO10 = 1;
}
//___________________________________________________________________________________________________________________________________________________________________________________________













//void SCIA_Read_Line(unsigned char *bfr)
//{
//    Uint16 ReceivedChar;
//    SCIA_set_RX();
//
//    for(;;)
//    {
//          while(SciaRegs.SCIFFRX.bit.RXFFST !=1);
//          ReceivedChar = SciaRegs.SCIRXBUF.all;
//          if(ReceivedChar=='\r') return;
//          else
//          {
//              *bfr=ReceivedChar;
//              bfr++;
//          }
//    }
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//unsigned char SCIA_Data_Received(void)
//{
////    if(SciaRegs.SCIFFRX.bit.RXFFST ==0) return 0;
////    SerialA.bfr[SerialA.ptr_rx] = SciaRegs.SCIRXBUF.all;
////    SerialA.ptr_rx++;
////    return -1;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//unsigned char SCIA_Received(void)
//{
////    unsigned char ReceivedChar;
////
////    if(SciaRegs.SCIFFRX.bit.RXFFST ==0) return;
////    ReceivedChar = SciaRegs.SCIRXBUF.all;
////    if(ReceivedChar=='\r')
////    {
////        SerialA.ptr_rx=0;
////        return -1;
////    }
////    else
////    {
////       SerialA.bfr[SerialA.ptr_rx]=ReceivedChar;
////       SerialA.ptr_rx++;
////    }
////    return 0;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//void set_Test_Baud_Val(unsigned char val)
//{
//    SciaRegs.SCILBAUD    =val;
//}

//_______________________________________________________________________________________________________________________
//void SCIA_msg(char * msg)
//{
//    int i,j;
//
//    SCIA_set_TX();
//
//    i = 0;
//   do     //while(*(msg+i) != '\0')
//    {
//       j=*(msg+i);
//        SCIA_put(j);
//        i++;
//    }while(i != 9);// while(i<8);
//    SCIA_set_RX();
//}
//________________________________________________________________________________________________________________________________________________________
//void SCIA_msg_by_count(char * msg,unsigned char count)
//{
//    int i;
//    SCIA_set_TX();
//    i = 0;
//    do
//    {
//        SCIA_put(*(msg+i));
//        i++;
//    }while(i<=count+1);
//    SCIA_set_RX();
//}
////________________________________________________________________________________________________________________________________________________________
//void SCIA_Send(unsigned char * msg,unsigned char count)
//{
//    while(count>0)
//    {
//        SCIA_put(*msg);
//        count--;
//        msg++;
//    }
//    SCIA_set_RX();
//}
//////____________________________________________________________________________________________________________________________________________________________________________________________
//void SCIA_put(int a)
//{
//    while (SciaRegs.SCIFFTX.bit.TXFFST != 0);
//    SciaRegs.SCITXBUF=a;
//}
//
//



























//#include "SCIB.h"
//
//#include "F2805x_Cla_typedefs.h"// F2806x CLA Type definitions
//#include "F2805x_Device.h"     // F2805x Headerfile Include File
////_______________________________________________________________________________________________________________________
//void SCIB_Config(void)
//{
//   EALLOW;
//        GpioCtrlRegs.GPAPUD.bit.GPIO23 = 0;  // Enable pull-up for GPIO23 (SCIRXDB)
//        GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;  // Enable pull-up for GPIO14 (SCITXDB)
//
//        GpioCtrlRegs.GPAQSEL2.bit.GPIO23 = 3;   // Asynch input GPIO23 (SCIRXDB)
//
//        GpioCtrlRegs.GPAMUX2.bit.GPIO23 = 3;       // Configure GPIO23 for SCIRXDB
//        GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 2;       // Configure GPIO14 for SCITXDB
//
//    EDIS;
//
//    // Initialize the SCI FIFO
//    ScibRegs.SCIFFTX.all=0xE040;
//    ScibRegs.SCIFFRX.all=0x2044;
//    ScibRegs.SCIFFCT.all=0x0;
//
//    // Note: Clocks were turned on to the SCIA peripheral
//    // in the InitSysCtrl() function
//    ScibRegs.SCICCR.all = 0x0007;     // 1 stop bit,  No loopback
//                                      // No parity, 8 char bits,
//                                      // async mode, idle-line protocol
//    ScibRegs.SCICTL1.all = 0x0003;   // enable TX, RX, internal SCICLK,
//                                     // Disable RX ERR, SLEEP, TXWAKE
//    ScibRegs.SCICTL2.all = 0x0003;
//    ScibRegs.SCICTL2.bit.TXINTENA = 1;
//    ScibRegs.SCICTL2.bit.RXBKINTENA = 1;
//
//    ScibRegs.SCIHBAUD    = 0x0000;  // 9600 baud @LSPCLK = 15MHz(60 MHz SYSCLK)
//    ScibRegs.SCILBAUD    = 0x00C2;
//
//    ScibRegs.SCICTL1.all = 0x0023;  // Relinquish SCI from Reset
//
//
//
//
//
//
//    // RS485 RE-DE Control PIN
//    EALLOW;
//       GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 0;
//       GpioCtrlRegs.GPADIR.bit.GPIO10 = 1;
//    EDIS;
//}
////_______________________________________________________________________________________________________________________
//void SCIB_msg(char * msg)
//{
//    int i;
//
//    SCIB_set_TX();
//
//    i = 0;
//    while(*(msg+i) != '\0')
//    {
//        SCIB_put(*(msg+i));
//        i++;
//    }
//}
////____________________________________________________________________________________________________________________________________________________________________________________________
//void SCIB_put(int a)
//{
//    while (ScibRegs.SCIFFTX.bit.TXFFST != 0);
//    ScibRegs.SCITXBUF=a;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//void SCIB_set_TX(void)
//{
//    GpioDataRegs.GPASET.bit.GPIO10= 1;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//void SCIB_set_RX(void)
//{
//    GpioDataRegs.GPACLEAR.bit.GPIO10 = 1;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//void SCIB_Read_Line(unsigned char *bfr)
//{
//    Uint16 ReceivedChar;
//    SCIB_set_RX();
//
//    for(;;)
//    {
//          while(ScibRegs.SCIFFRX.bit.RXFFST !=1);
//          ReceivedChar = ScibRegs.SCIRXBUF.all;
//          if(ReceivedChar=='\r') return;
//          else
//          {
//              *bfr=ReceivedChar;
//              bfr++;
//          }
//    }
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//
//
//
