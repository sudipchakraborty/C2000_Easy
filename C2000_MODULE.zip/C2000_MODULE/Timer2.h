#ifndef TIMER2_H_
#define TIMER2_H_

#include "DSP28x_Project.h"

__interrupt void timer2_isr(void);
void Timer2_Default_Config(void);
void Timer2_Start(void);
void Timer2_Stop(void);
void Timer2_Reload(void);
Uint32 Timer2_Read(void);
Uint32 Timer2_Read_Period(void);

extern struct CPUTIMER_VARS CpuTimer2;
//_________________________________________________________________________________________________________________
__interrupt void timer2_isr(void)
{
    CpuTimer2.InterruptCount++;
    GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1; // Toggle GPIO34 once per 500 ms

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
//_________________________________________________________________________________________________________________
void Timer2_Default_Config(void)
{
    float Freq;
    float Period;
    Uint32  temp;
    
    EALLOW;  // This is needed to write to EALLOW protected registers
     PieVectTable.TINT0 = &timer2_isr;
    EDIS;    // This is needed to disable write to EALLOW protected registers
    
    CpuTimer2.RegsAddr = &CpuTimer2Regs;
    CpuTimer2Regs.PRD.all  = 0xFFFFFFFF;
    
    CpuTimer2Regs.TPR.all  = 0;     // Initialize pre-scale counter to divide by 1 (SYSCLKOUT)
    CpuTimer2Regs.TPRH.all = 0;
    CpuTimer2Regs.TCR.bit.TSS = 1;    // Make sure timer is stopped
    CpuTimer2Regs.TCR.bit.TRB = 1;  // Reload all counter register with period value
    CpuTimer2.InterruptCount = 0;  // Reset __interrupt counters

    Freq=60;
    Period=500000;
    
    CpuTimer2.CPUFreqInMHz = Freq;
    CpuTimer2.PeriodInUSec = Period;
    temp = (long) (Freq * Period);
    CpuTimer2.RegsAddr->PRD.all = temp;
    
    // Set pre-scale counter to divide by 1 (SYSCLKOUT)
    CpuTimer2.RegsAddr->TPR.all  = 0;
    CpuTimer2.RegsAddr->TPRH.all  = 0;
    
    // Initialize timer control register
    CpuTimer2.RegsAddr->TCR.bit.TSS = 1;    // 1 = Stop, 0 = Start/Restart Timer
    CpuTimer2.RegsAddr->TCR.bit.TRB = 1;    // 1 = Reload Timer
    CpuTimer2.RegsAddr->TCR.bit.SOFT = 0;
    CpuTimer2.RegsAddr->TCR.bit.FREE = 0;   // Timer Free Run Disabled
    CpuTimer2.RegsAddr->TCR.bit.TIE = 1;    // 0 = Disable, 1 = Enable Interrupt
    
    // Reset __interrupt counter
    CpuTimer2.InterruptCount = 0;
    
    CpuTimer2Regs.TCR.all = 0x4001; // Use write-only instruction to clear TSS
    /////////////////////////////////
    IER |= M_INT1;
    
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;  // Enable TINT0 in the PIE: Group 1 __interrupt 7
    EINT;   // Enable Global __interrupt INTM
    ERTM;   // Enable Global realtime __interrupt DBGM
}
//_________________________________________________________________________________________________________________
void Timer2_Start(void)
{
   CpuTimer2Regs.TCR.bit.TSS = 0;
}
//_________________________________________________________________________________________________________________
void Timer2_Stop(void)
{
   CpuTimer2Regs.TCR.bit.TSS = 1;
}
//_________________________________________________________________________________________________________________
void Timer2_Reload(void)
{
    CpuTimer2Regs.TCR.bit.TRB = 1;
}
//_________________________________________________________________________________________________________________
Uint32 Timer2_Read(void)
{
    return CpuTimer2Regs.TIM.all;
}
//_________________________________________________________________________________________________________________
Uint32 Timer2_Read_Period(void)
{
    return CpuTimer2Regs.PRD.all;
}
//_________________________________________________________________________________________________________________








#endif /* TIMER0_H_ */
