

#ifndef ANORA_MODBUS_MODBUSTIMER_H_
#define ANORA_MODBUS_MODBUSTIMER_H_

void Time_Start(void);
unsigned char TimeOut(void);
///////////////////////////////////
struct ModbusTimer
{
    long TimeOut_Reg;


};


#endif /* ANORA_MODBUS_MODBUSTIMER_H_ */
