#ifndef ALL_MODULE_H_
#define ALL_MODULE_H_


#include "io.h"
#include "DSP28x_Project.h"
#include "SCIA.h"
#include "SCIB.h"
#include "SCIC.h"
#include "DSP28x_Project.h"
#include "Heartbit.h"
#include "modbus.h"
#include "ModbusTimer.h"
#include "WS2812B.h"
#include "sciC_NoInt.h"
#include "BUZZER.h"

#include "Timer0.h"
#include "Timer1.h"
#include "Timer2.h"
#include "I2C_Software.h"
#include "MCP7940N.h"
#include "modbus_registers.h"
#include "ADC.h"
//#include "SPI.h"
#include "WS2811.h"
#include "WS2811_Clock.h"




#endif
