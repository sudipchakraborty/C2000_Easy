//
//
//
//
//
//struct Amb_temp
//{
//	unsigned int avj_bfr[10];
//	unsigned int temp;
//};
//
//
//
//unsigned int Get_Ambient_Temperature(void);
//void Get_Amb_Temp_Ascii(unsigned char *bfr);
////_____________________________________________________________________________________________________________________________
