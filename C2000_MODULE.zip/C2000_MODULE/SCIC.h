#ifndef SCIC_H_
#define SCIC_H_


#define scic_bfr_count   20
///////////////////////////
void SCIC_Config(long baud_rate);
void scic_Port_Config(void);
void scic_Interrupt_Config(void);
void scic_Module_config(void);
void SCIC_msg(char * msg);
void SCIC_put(int a);
void SCIC_set_TX(void);
void SCIC_set_RX(void);
void SCIC_Read_Line(unsigned char *bfr);
//void set_Test_Baud_Val(unsigned char val);
void SCIC_Set_Baud_Rate(long baud_rate);
void SCIC_Purge(void);
unsigned char SCIC_Received(void);
unsigned char SCIC_Data_Received(void);
void SCIC_msg_by_count(char * msg,unsigned char count);
void SCIC_Send(unsigned char * msg,unsigned char count);
unsigned char scic_Data_Received(void);
///////////////////////////
struct str_SCIC
{
    unsigned char scic_bfr_rx[scic_bfr_count];
    unsigned char scic_bfr_tx[scic_bfr_count];
    unsigned char scic_bfr_ptr_rx;
    unsigned char scic_bfr_ptr_tx;
    unsigned char scic_tx_count;
    unsigned char scic_received;
};

#endif /* SCIC_H_ */
