#ifndef SCIB_H_
#define SCIB_H_

#define scib_bfr_count   20
///////////////////////////
void SCIB_Config(long baud_rate);
void sciB_Port_Config(void);
void scib_Module_config(void);
void sciB_Interrupt_Config(void);
void SCIB_msg(char * msg);
void SCIB_put(int a);
void SCIB_set_TX(void);
void SCIB_set_RX(void);
void SCIB_Read_Line(unsigned char *bfr);
void SCIB_Set_Baud_Rate(long baud_rate);
void SCIB_Purge(void);
unsigned char SCIB_Received(void);
unsigned char sciB_Data_Received(void);
void SCIB_msg_by_count(char * msg,unsigned char count);
void SCIB_Send(unsigned char * msg,unsigned char count);
void SCIB_RE_DE_Test(void);
///////////////////////////
struct str_SCIB
{
    unsigned char scib_bfr_rx[scib_bfr_count];
    unsigned char scib_bfr_tx[scib_bfr_count];
    unsigned char scib_bfr_ptr_rx;
    unsigned char scib_bfr_ptr_tx;
    unsigned char scib_tx_count;
    unsigned char scib_received;
};


#endif /* SCIB_H_ */
