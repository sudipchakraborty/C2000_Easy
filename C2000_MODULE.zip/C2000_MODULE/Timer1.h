#ifndef TIMER1_H_
#define TIMER1_H_

#include "DSP28x_Project.h"

__interrupt void timer1_isr(void);
void Timer1_Default_Config(void);
void Timer1_Start(void);
void Timer1_Stop(void);
void Timer1_Reload(void);
Uint32 Timer1_Read(void);
Uint32 Timer1_Read_Period(void);

extern struct CPUTIMER_VARS CpuTimer1;
//_________________________________________________________________________________________________________________
__interrupt void timer1_isr(void)
{
  //  CpuTimer0.InterruptCount++;
  //  GpioDataRegs.GPBTOGGLE.bit.GPIO34 = 1; // Toggle GPIO34 once per 500 ms

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
//_________________________________________________________________________________________________________________
void Timer1_Default_Config(void)
{
    float Freq;
    float Period;
    Uint32  temp;
    
    EALLOW;  // This is needed to write to EALLOW protected registers
     PieVectTable.TINT0 = &timer1_isr;
    EDIS;    // This is needed to disable write to EALLOW protected registers
    
    CpuTimer1.RegsAddr = &CpuTimer1Regs;
    CpuTimer1Regs.PRD.all  = 0xFFFFFFFF;
    
    CpuTimer1Regs.TPR.all  = 0;     // Initialize pre-scale counter to divide by 1 (SYSCLKOUT)
    CpuTimer1Regs.TPRH.all = 0;
    CpuTimer1Regs.TCR.bit.TSS = 1;    // Make sure timer is stopped
    CpuTimer1Regs.TCR.bit.TRB = 1;  // Reload all counter register with period value
    CpuTimer1.InterruptCount = 0;  // Reset __interrupt counters

    Freq=60;
    Period=500000;
    
    CpuTimer1.CPUFreqInMHz = Freq;
    CpuTimer1.PeriodInUSec = Period;
    temp = (long) (Freq * Period);
    CpuTimer1.RegsAddr->PRD.all = temp;
    
    // Set pre-scale counter to divide by 1 (SYSCLKOUT)
    CpuTimer1.RegsAddr->TPR.all  = 0;
    CpuTimer1.RegsAddr->TPRH.all  = 0;
    
    // Initialize timer control register
    CpuTimer1.RegsAddr->TCR.bit.TSS = 1;    // 1 = Stop, 0 = Start/Restart Timer
    CpuTimer1.RegsAddr->TCR.bit.TRB = 1;    // 1 = Reload Timer
    CpuTimer1.RegsAddr->TCR.bit.SOFT = 0;
    CpuTimer1.RegsAddr->TCR.bit.FREE = 0;   // Timer Free Run Disabled
    CpuTimer1.RegsAddr->TCR.bit.TIE = 1;    // 0 = Disable, 1 = Enable Interrupt
    
    // Reset __interrupt counter
    CpuTimer1.InterruptCount = 0;
    
    CpuTimer1Regs.TCR.all = 0x4001; // Use write-only instruction to clear TSS
    /////////////////////////////////
    IER |= M_INT1;
    
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;  // Enable TINT0 in the PIE: Group 1 __interrupt 7
    EINT;   // Enable Global __interrupt INTM
    ERTM;   // Enable Global realtime __interrupt DBGM
}
//_________________________________________________________________________________________________________________
void Timer1_Start(void)
{
   CpuTimer1Regs.TCR.bit.TSS = 0;
}
//_________________________________________________________________________________________________________________
void Timer1_Stop(void)
{
   CpuTimer1Regs.TCR.bit.TSS = 1;
}
//_________________________________________________________________________________________________________________
void Timer1_Reload(void)
{
    CpuTimer1Regs.TCR.bit.TRB = 1;
}
//_________________________________________________________________________________________________________________
Uint32 Timer1_Read(void)
{
    return CpuTimer1Regs.TIM.all;
}
//_________________________________________________________________________________________________________________
Uint32 Timer1_Read_Period(void)
{
    return CpuTimer1Regs.PRD.all;
}
//_________________________________________________________________________________________________________________








#endif /* TIMER0_H_ */
