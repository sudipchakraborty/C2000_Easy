void Init_Buzzer(void);
void beep(void);
void beep_low(void);
void error_beep(unsigned char count);
