#include "modbus.h"
#include <stdint.h>
#include <string.h>
#include "modbus_registers.h"
////////////////////////
struct modbus mb;
ModbusRegister  Modbus_Register[200];
//________________________________________________________________________________________________________________________________
void modbus_Init(unsigned char device_addr)
{
    mb.FSM=MODBUS_STATE_IDLE;
    mb.MODBUS_USART_RECEIVE_FLAG=false;
    mb.slave_address=device_addr;
    mb.multi_cast_address=51;
}
//________________________________________________________________________________________________________________________________
void initialize_modbus_structure(void)
{
    //Device parameters....//
    set_modbus_register_info(&Modbus_Register[Modbus_Manufacturer],     Modbus_Manufacturer     ,10);
    set_modbus_register_info(&Modbus_Register[Modbus_LOCATION],         Modbus_LOCATION         ,10);
    set_modbus_register_info(&Modbus_Register[Modbus_DEVICE_ID],        Modbus_DEVICE_ID        , 5);
    set_modbus_register_info(&Modbus_Register[Modbus_DEVICE_TYPE],      Modbus_DEVICE_TYPE      , 5);
    set_modbus_register_info(&Modbus_Register[Modbus_SERIAL_NUMBER],    Modbus_SERIAL_NUMBER    , 5);
    set_modbus_register_info(&Modbus_Register[Modbus_FW_VERSION],       Modbus_FW_VERSION       , 5);
    set_modbus_register_info(&Modbus_Register[Modbus_HW_VERSION],       Modbus_HW_VERSION       , 1);

    // Register block for Digital Input
    set_modbus_register_info(&Modbus_Register[Modbus_ID],               Modbus_ID               , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_FAULT],            Modbus_FAULT            , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_EXT_DIGITAL_IN],   Modbus_EXT_DIGITAL_IN   , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_BUS_I_OC],         Modbus_BUS_I_OC         , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_PHASE_I_OC],       Modbus_PHASE_I_OC       , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_Temperature_1],    Modbus_Temperature_1    , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_Temperature_2],    Modbus_Temperature_2    , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_Temperature_3],    Modbus_Temperature_3    , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_U5_GAIN_Select],   Modbus_U5_GAIN_Select   , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_U6_GAIN_Select],    Modbus_U6_GAIN_Select  , 1);

    // Register Block for Digital Output
    set_modbus_register_info(&Modbus_Register[Modbus_GATE_HB1_HS],      Modbus_GATE_HB1_HS      , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_GATE_HB1_LS],      Modbus_GATE_HB1_LS      , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_GATE_HB2_HS],      Modbus_GATE_HB2_HS      , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_GATE_HB2_LS],      Modbus_GATE_HB2_LS      , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_GATE_HB3_HS],      Modbus_GATE_HB3_HS      , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_GATE_HB3_LS],      Modbus_GATE_HB3_LS      , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_FAN_CONTROL],      Modbus_FAN_CONTROL      , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_PWM_ENABLE],       Modbus_PWM_ENABLE       , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_EXT_DIGITAL_OUT0], Modbus_EXT_DIGITAL_OUT0 , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_EXT_DIGITAL_OUT1], Modbus_EXT_DIGITAL_OUT1 , 1);

    // Register Block for Analog Input
    set_modbus_register_info(&Modbus_Register[Modbus_I_PHASE_SNS],      Modbus_I_PHASE_SNS       , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_VREMOTE_SNS],      Modbus_I_PHASE_SNS       , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_VBUS_SNS],         Modbus_I_PHASE_SNS       , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_VPHASE_SNS],       Modbus_I_PHASE_SNS       , 1);
    set_modbus_register_info(&Modbus_Register[Modbus_I_BUS_SNS],        Modbus_I_PHASE_SNS       , 1);
     ////////////////////////////////////
}
//________________________________________________________________________________________________________________________
unsigned char initialize_holding_registers(void)
{
    unsigned char tmpData[20];
    unsigned int tmp16Data[20];
    unsigned int configData[1];
  //  ApplicationError error = ERROR_NONE;
    //Device Parameters
    set_holding_registers(&Modbus_Register[Modbus_Manufacturer],"WLFSP",5,0);
    set_holding_registers(&Modbus_Register[Modbus_LOCATION],"AIPL",5,0);
    set_holding_registers(&Modbus_Register[Modbus_DEVICE_ID],"12345",5,0);
    set_holding_registers(&Modbus_Register[Modbus_DEVICE_TYPE],"PWR",5,0);
    set_holding_registers(&Modbus_Register[Modbus_SERIAL_NUMBER],"457844",5,0);
    set_holding_registers(&Modbus_Register[Modbus_FW_VERSION],"1.0",5,0);
    set_holding_registers(&Modbus_Register[Modbus_HW_VERSION],"1.0",5,0);






//
//    error = read_eeprom(&EE_LOCATION,&tmpData);
//    if (error != ERROR_NONE) return error;
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_LOCATION],tmpData,10,0);
//
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_DEVICE_ID],"    400003",5,0);
//
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_DEVICE_TYPE]," PCB",3,0);
//
//    error = read_eeprom(&EE_SERIAL_NUMBER,&tmpData);
//    if (error != ERROR_NONE) return error;
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_SERIAL_NUMBER],tmpData,5,0);
//
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_FW_VERSION],VERSION,5,0);
//
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_HW_VERSION],"A1",1,0);
//
//    HOLDING_REGISTER[MODBUS_REGISTER[MODBUS_PROFILE].address] = 1;
//
//    error = read_eeprom(&EE_MODBUS_ADDRESS,&tmpData);
//    if (error != ERROR_NONE) return error;
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_ADDRESS],tmpData,1,0);
//
//    error = read_eeprom(&EE_GROUP_ADDRESS,&tmpData);
//    if (error != ERROR_NONE) return error;
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_GROUP_ADDRESS],tmpData,1,0);
//
//                // >>>>>>>>Control registers>>>>>>>>>//
//
//                //>>>>>>>>>Data Registers>>>>>>>>>>>>//
//
//
//    error = target_direction(&dir);
//    if (error != ERROR_NONE) return error;
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_DIRECTION],&dir,1,0);
//
//    error = target_position(&pos);
//    if (error != ERROR_NONE) return error;
//    set_holding_registers(&MODBUS_REGISTER[MODBUS_CURRENT_POSITION],&pos,1,0);
//
//   error = get_sensor_result(&result);
//   if (error != ERROR_NONE) return error;
//   deserialize_32bits_to_16bits(&result,&tmp16Data,1);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SENSOR_RAW_DATA],tmp16Data,2,0);
//
//   error = get_channel1_result(&result);
//   if (error != ERROR_NONE) return error;
//   deserialize_32bits_to_16bits(&result,&tmp16Data,1);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SENSOR1_RAW_DATA],&tmp16Data,2,0);
//
//
//          //>>>>>>>>>Calibration Register>>>>>>//
//
//   error = read_eeprom(&EE_POINTS_CALIBRATED,&tmpData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_POINTS_CAL],tmpData,2,0);
//
//   error = read_eeprom(&EE_TOLERANCE_REGISTER,&tmpData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_TOLERANCE_REG],tmpData,1,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT1,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT1],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT2,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT2],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT3,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT3],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT4,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT4],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT5,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT5],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT6,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT6],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT7,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT7],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT8,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT8],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT9,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT1],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT10,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT1],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT11,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT1],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT12,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT12],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT13,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT13],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT14,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT14],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT15,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT15],&tmp16Data,2,0);
//
//   error = read_eeprom(&EE_SALIENT_POINT16,&tmpData);
//   if (error != ERROR_NONE) return error;
//   deserialize_8bits_to_16bits(tmpData,tmp16Data,4);
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SALIENT_POINT16],&tmp16Data,2,0);
//
//          //>>>>>>>>>Debug Registers>>>>>>>>>>>>//
//   error = read_manufacture_id(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_LDC_MANF_ID],&configData,1,0);
//
//   error = read_device_id(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_LDC_DEV_ID],&configData,1,0);
//
//   error = read_rcount0(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SENSOR0_RCOUNT],&configData,1,0);
//
//   error = read_rcount1(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SENSOR1_RCOUNT],&configData,1,0);
//
//   error = read_offset0(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SENSOR0_OFFSET],&configData,1,0);
//
//   error = read_offset1(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SENSOR1_OFFSET],&configData,1,0);
//
//   error = read_settlecount0(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SEN0_SETTLECNT],&configData,1,0);
//
//   error = read_settlecount1(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SEN1_SETTLECNT],&configData,1,0);
//
//   error = read_clockdivider0(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SEN0_CLK_DIV],&configData,1,0);
//
//   error = read_clockdivider1(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SEN1_CLK_DIV],&configData,1,0);
//
//   error = read_drivecurrent0(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SEN0_DRIVE_CRNT],&configData,1,0);
//
//   error = read_drivecurrent1(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_SEN1_DRIVE_CRNT],&configData,1,0);
//
//   error =  read_status(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_LDC_STATUS],&configData,1,0);
//
//   error =  read_error(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_LDC_ERR_CONFG],&configData,1,0);
//
//   error =  read_config(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_LDC_CONFIG],&configData,1,0);
//
//   error = read_muxconfig(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_LDC_MUX_CONFIG],&configData,1,0);
//
//   error =  read_reset(&configData);
//   if (error != ERROR_NONE) return error;
//   set_holding_registers(&MODBUS_REGISTER[MODBUS_LDC_RESET_DEV],&configData,1,0);
//    return error;

   }




unsigned char process_modbus_request(ModbusPdu* request, ModbusPdu* response)
{
    unsigned char return_code = NO_ERROR;
    switch(request->function_code)
    {
        case READ_HOLDING_REGISTER:
        {
            return_code = read_holding_registers(request, response);
            break;
        }
        case WRITE_SINGLE_REGISTER:
        {
            return_code = write_single_register(request, response);
            break;
        }
        case WRITE_MULTIPLE_REGISTER:
        {
            return_code = write_multiple_register(request, response);
            break;
        }
        default:
        {
            response->function_code = 0x80 + request->function_code;
            response->data[0] = ILLEGAL_FUNCTION;
            return_code = ILLEGAL_FUNCTION;
        }
        return return_code;
    }
}
//________________________________________________________________________________________________________________________________
void set_modbus_register_info(ModbusRegister *reg, uint16_t add, unsigned char len)
{
    reg->address = add;
    reg->length = len;
}
//________________________________________________________________________________________________________________________________
unsigned char get_holding_registers(ModbusRegister *reg, uint16_t * data,unsigned char regCount)
{
    unsigned char index;
    if (regCount > reg->length)
        return ERROR_MODBUS_BASE + ERROR_MODBUS_HOLDINGREG_SIZE;

    for(index=0; index<reg->length; index++)
        data[index] = mb.HOLDING_REGISTER[reg->address+index] ;

    return ERROR_MODBUS_NONE;
}
//________________________________________________________________________________________________________________________________
unsigned char set_holding_registers(ModbusRegister *reg, uint16_t * data, unsigned char regCount, uint16_t padVal)
{
    unsigned char index;
    if (regCount >reg->length)
        return ERROR_MODBUS_BASE + ERROR_MODBUS_HOLDINGREG_SIZE;

    for(index=0; index<reg->length; index++)
    {
        if (index < regCount)
            mb.HOLDING_REGISTER[index+reg->address] = data[index];
        else
            mb.HOLDING_REGISTER[index+reg->address] = padVal;
    }

    return ERROR_MODBUS_NONE;
}
//________________________________________________________________________________________________________________________________
unsigned char set_holding_registers_string(ModbusRegister *reg, unsigned char * data, unsigned char regCount, unsigned char padVal)
{

    unsigned char index;
    if (regCount >reg->length)
        return ERROR_MODBUS_BASE + ERROR_MODBUS_HOLDINGREG_SIZE;
    int inpIndex=0;
    for(index=0; index<reg->length; index++)
    {
        if (index < regCount)
        {
            mb.HOLDING_REGISTER[index+reg->address] = (data[inpIndex] << 8)+ data[inpIndex+1];
        }
        else
        {
            mb.HOLDING_REGISTER[index+reg->address] = (padVal << 8) + padVal;
        }
        inpIndex = inpIndex+2;
    }

    return ERROR_MODBUS_NONE;
}
//________________________________________________________________________________________________________________________________
uint16_t modbus_silent_interval(float cpu_clk, uint16_t timer_div, uint16_t baud_rate)
{
    uint16_t cmp;
    cmp = (uint16_t) (28*cpu_clk/((float)(timer_div*baud_rate))) + 1; // 3.5 chracters => 3.5*8
    return cmp;
}
//________________________________________________________________________________________________________________________________
unsigned char read_holding_registers(ModbusPdu* request, ModbusPdu* response)
{
    uint16_t start_address, register_len;
    unsigned char byte_count;
    unsigned char return_code = NO_ERROR;
    uint16_t index, data_index, end_address;

    register_len = ((request->data[2] << 8) | request->data[3]);
    if ((register_len < 1) | (register_len > 0x007D))
    {
        response->function_code = 0x80 + request->function_code;
        response->data[0] = ILLEGAL_DATA_VALUE;
        response->len = 1;
        return ILLEGAL_DATA_VALUE;
    }

    start_address = ((request->data[0] << 8) | request->data[1]);
    end_address = start_address + register_len;
    if (start_address + register_len > mb.HOLDING_REGISTER_SIZE)
    {
        response->function_code = 0x80 + request->function_code;
        response->data[0] = ILLEGAL_DATA_ADDRESS;
        response->len = 1;
        return ILLEGAL_DATA_ADDRESS;
    }

    // function code
    response->function_code =   READ_HOLDING_REGISTER;
    // number of bytes = register length * 2
    byte_count = register_len << 1;
    response->data[0]= byte_count;

    // copy data over from holding registers
    data_index = 1;
    for (index=start_address; index<end_address; index++)
    {
        response->data[data_index] = (mb.HOLDING_REGISTER[index] >> 8) & (0xFF);
        response->data[data_index+1] = (mb.HOLDING_REGISTER[index]) & (0xFF);
        data_index = data_index + 2;
    }


    // length
    response->len = byte_count + 1 ;//register_len + 1;

    return ERROR_MODBUS_NONE;
}
//________________________________________________________________________________________________________________________________
unsigned char write_single_register(ModbusPdu* request, ModbusPdu* response)
{
    uint16_t register_address, register_data, tmp_holding_data;
    unsigned char return_code = NO_ERROR;


    register_data = ((request->data[2] << 8) | request->data[3]);
    register_address = ((request->data[0] << 8) | request->data[1]);
    if (register_address > mb.HOLDING_REGISTER_SIZE)
    {
        response->function_code = 0x80 + request->function_code;
        response->data[0] = ILLEGAL_DATA_ADDRESS;
        response->len = 1;
        return ILLEGAL_DATA_ADDRESS;

    }

    // Copy the data to holding registers
    mb.HOLDING_REGISTER[register_address]=register_data;
    // Run the action for the address
 //   return_code = modbus_action_function(register_address);
    // If the action returns an error, send response
    if (return_code != NO_ERROR)
    {
        mb.HOLDING_REGISTER[mb.ERROR_ADDRESS] = return_code;
        response->function_code = 0x80 + request->function_code;
        response->data[0] = SLAVE_DEVICE_FAILURE;
        response->len = 1;
        return SLAVE_DEVICE_FAILURE;
    }

    // function code
    response->function_code =   request->function_code;
    response->data[0] = request->data[0];
    response->data[1] = request->data[1];
    response->data[2] = request->data[2] ;
    response->data[3] = request->data[3];
    response->len = 4;

    return ERROR_MODBUS_NONE;
}
//________________________________________________________________________________________________________________________________
unsigned char write_multiple_register(ModbusPdu* request, ModbusPdu* response)
{
    uint16_t start_address, register_quantity, num_bytes, end_address;
    unsigned char return_code = NO_ERROR;
    uint16_t index, data_index;
    /* Frame
    Start address
    Start address
    Num regs
    Num regs
    Num bytes
    Data
    */
    register_quantity = ((request->data[2] << 8) | request->data[3]);
    num_bytes = request->data[4];
    if (((register_quantity < 1) | (register_quantity > 0x007D)) & (num_bytes = (register_quantity<<2)))
    {
        response->function_code = 0x80 + request->function_code;
        response->data[0] = ILLEGAL_DATA_VALUE;
        response->len = 1;
        return ILLEGAL_DATA_VALUE;
    }

    start_address = ((request->data[0] << 8) | request->data[1]);
    end_address = start_address + register_quantity;
    if (start_address + register_quantity > mb.HOLDING_REGISTER_SIZE)
    {
        response->function_code = 0x80 + request->function_code;
        response->data[0] = ILLEGAL_DATA_ADDRESS;
        response->len = 1;
        return ILLEGAL_DATA_ADDRESS;
    }

    // copy data over to holding registers
    data_index = 5; // Data starts at the 5th index
    for (index=start_address; index<end_address; index++)
    {
        mb.HOLDING_REGISTER[index] = (request->data[data_index] << 8) | (request->data[data_index+1]);
        data_index = data_index + 2;
    }

    // Perform the action for that address from main application
 //   return_code = modbus_action_function(start_address);

    // If the action returns an error, send response
    if (return_code != NO_ERROR)
    {
        mb.HOLDING_REGISTER[mb.ERROR_ADDRESS] = return_code;
        response->function_code = 0x80 + request->function_code;
        response->data[0] = SLAVE_DEVICE_FAILURE;
        response->len = 1;
        return SLAVE_DEVICE_FAILURE;
    }

    // function code
    response->function_code =   request->function_code;
    // start address
    response->data[0] = request->data[0];
    response->data[1] = request->data[1];
    // Quantity
    response->data[2] = request->data[2];
    response->data[3] = request->data[3];
    response->len = 4;


    return ERROR_MODBUS_NONE;
}
//________________________________________________________________________________________________________________________________
void register_slave_address(unsigned char slave_address)
{
    mb.slave_address = slave_address;
}
//________________________________________________________________________________________________________________________________
void register_multi_cast_adress(unsigned char addr)
{
    mb.multi_cast_address = addr;
}
//________________________________________________________________________________________________________________________________
uint16_t modbus_crc_calculate(unsigned char* data, unsigned char len)
{
    unsigned char i = 0;
    uint16_t crc = 0xFFFF;
    for (i = 0; i < len; i++)
   crc = crc16_update(crc, data[i]);
    return crc; // must be 0
}
//________________________________________________________________________________________________________________________________
unsigned int crc16_update(unsigned int crc, unsigned char a)
{
    int i;
    crc ^= a;
    for (i = 0; i < 8; ++i)
    {
        if (crc & 1)
        crc = (crc >> 1) ^ 0xA001;
        else
        crc = (crc >> 1);
    }
    return crc;
}
//________________________________________________________________________________________________________________________________
unsigned char modbus_crc_check(unsigned char* data, unsigned char len)
{
    uint16_t calculated_crc = modbus_crc_calculate(&data[0], (len-2));
    uint16_t received_crc = (((uint16_t)data[len - 1]) << 8) | data[len-2];
    return (calculated_crc == received_crc) ? 1 : 0;
}
//________________________________________________________________________________________________________________________________
unsigned char modbus_request_adu(ModbusAdu* adu, unsigned char *data, unsigned char data_length)
{
    if (modbus_crc_check(&data[0], data_length) != 1)
    return 0;

    if ((data[0] != mb.slave_address) && (data[0] != 0) && (data[0] != mb.multi_cast_address))
    return 0;

    adu->address = data[0];
    adu->modbus_pdu.function_code = data[1];
    adu->modbus_pdu.len = data_length - 4;
    memcpy(&adu->modbus_pdu.data, &data[2], adu->modbus_pdu.len);
    memcpy(&adu->crc, &data[(adu->modbus_pdu.len + 1)], 2);

    return 1;
}
//________________________________________________________________________________________________________________________________
unsigned char modbus_response_adu(ModbusAdu* adu, unsigned char* data)
{
    data[0] = adu->address;
    data[1] = adu->modbus_pdu.function_code;
    memcpy(&data[2], &adu->modbus_pdu.data[0], adu->modbus_pdu.len);
    unsigned char len = adu->modbus_pdu.len + 2;
    uint16_t crc = modbus_crc_calculate(&data[0], len);
    data[len] = crc&0xFF;
    data[len+1] = ((crc>>8)&0xFF);
    return adu->modbus_pdu.len + 4;
}
//________________________________________________________________________________________________________________________________
unsigned char modbus_handler(unsigned char *bfr_request,unsigned char recv_count, unsigned char *bfr_response)
{
    ModbusAdu request;
    ModbusAdu response;
    unsigned char index;
    unsigned char request_ok;
    unsigned char rx_data[256];
    unsigned char tx_data[256];
    unsigned char response_data_len;

    // Copy all data
    for (index=0; index < recv_count; index++)
    rx_data[index] = *(bfr_request+index);
    // ensure slave id, CRC and get data into ADU structure
    request_ok = modbus_request_adu(&request,&rx_data,recv_count);

    // Process modbus request
    if(request_ok == 1)
    {
        process_modbus_request(&(request.modbus_pdu), &(response.modbus_pdu));

        if ((request.address != 0) |(request.address != mb.multi_cast_address))
        {
            response.address = mb.slave_address;
            response_data_len = modbus_response_adu(&response, &tx_data);
         //   modbus_tx_en(true);
          //  modbus_tx_en_delay();
          //  mb.MODBUS_TRANSMITTED_BYTES = 0;
            for(index=0; index<response_data_len; index++)
            {
                *(bfr_response+index)=tx_data[index];
            }
            return response_data_len;
              //  modbus_tx_byte(tx_data[index]);
        //    while(mb.MODBUS_TRANSMITTED_BYTES < response_data_len);
          //  modbus_tx_en_delay();
           // modbus_tx_en(false);
        }
    }

}
//________________________________________________________________________________________________________________________________
unsigned char serialize_16bits_to_8bits(uint16_t * data,unsigned char * dataOut, uint16_t inputCount)
{
    uint16_t index;
    uint16_t data_index = 0;
    for (index=0; index<inputCount; index++)
    {
        dataOut[data_index] = (data[index] >> 8) & (0xFF);
        dataOut[data_index + 1] = data[index] & 0xFF;
        data_index = data_index + 2;
    }
    return ERROR_UTILITY_NONE;
}
//________________________________________________________________________________________________________________________________
unsigned char deserialize_8bits_to_16bits(unsigned char * data,uint16_t * dataOut, uint16_t inputCount)
{
    uint16_t index = 0;
    uint16_t data_index = 0;
    while (index < inputCount)
    {
        dataOut[data_index] = (data[index] << 8) | (data[index+1]);
        data_index++;
        index = index + 2;
    }
    return ERROR_UTILITY_NONE;
}
//________________________________________________________________________________________________________________________________

