#include "Heartbit.h"





struct str_Heartbit     hbt;
//__________________________________________________________________________________________________________________
void Heartbit_LED_Init(void)
{

    hbt.delay_reg=0;




}
//__________________________________________________________________________________________________________________
void Blink_Heartbit_LED(void)
{
    hbt.delay_reg++;
    if(hbt.delay_reg>2000)
    {
        hbt.delay_reg=0;
        if(hbt.state==1)hbt.state=0; else hbt.state=1;
        digitalWrite(49,hbt.state);

        digitalWrite(45,hbt.state);
        digitalWrite(50,hbt.state);
        digitalWrite(62,hbt.state);
    }
}
//__________________________________________________________________________________________________________________

