#ifndef I2C_SOFTWARE_H_
#define I2C_SOFTWARE_H_


void I2C_Soft_Init(void);
void I2C_Soft_Test_SCL_PIN(void);
void I2C_Soft_Test_SDA_As_Output(void);
unsigned char I2C_Soft_Test_SDA_As_Input(void);
void I2C_Soft_delay(void);
void I2C_Soft_Start(void);
void I2C_Soft_Stop(void);
void I2C_Soft_Ack(void);
void I2C_Soft_NoAck(void);
void I2C_Soft_Write(unsigned char v_i2cData_u8);
unsigned char I2C_Soft_Read(unsigned char v_ackOption_u8);
void I2C_Soft_Clock(void);
unsigned char I2C_Soft_Ack_Received(void);
void I2C_Soft_Set_BUS_As_Input(void);
//https://github.com/ExploreEmbedded/8051_DevelopmentBoard/blob/master/Code/Keil_Sample_Codes/00-libfiles/i2c.c

//
//struct struct_I2C_soft
//{
//
//};

//static void i2c_Clock(void);
//static void i2c_Ack(void);
//static void i2c_NoAck(void);
//
//void I2C_Soft_Init(uint8_t SCL, uint8_t SDA);
//void I2C_Soft_Start(void);
//void I2C_Soft_Stop(void);
//void I2C_Soft_Ack(void);
//void I2C_Soft_NoAck(void);
//void I2C_Soft_Write(uint8_t v_i2cData_u8);
//uint8_t I2C_Soft_Read(uint8_t v_ackOption_u8);
//void I2C_Soft_Clock(void);
//void Test_SCL_PIN(void);
//void Test_SDA_As_Output(void);
//uint8_t Test_SDA_As_Input(void);
//void i2c_soft_delay(void);
//
//
//






#endif /* I2C_SOFTWARE_H_ */
