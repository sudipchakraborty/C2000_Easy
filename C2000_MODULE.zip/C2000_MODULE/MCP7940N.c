#include "F2805x_Cla_typedefs.h"    // F2806x CLA Type definitions
#include "F2805x_Device.h"          // F2805x Headerfile Include File
#include "I2C_Software.h"
#include "MCP7940N.h"

#define     MCP7940N_ADDRESS 0b11011110 //0xDE   // 0b11011110    // 0xDE  //  0xDE // 0x50
//_________________________________________________________________________________________________________________________________________________________
void MCP7940N_Write(unsigned char addr, unsigned char data)
{
    unsigned int i;

    I2C_Soft_Start();
    I2C_Soft_Write(MCP7940N_ADDRESS);
    I2C_Soft_Ack_Received();

    I2C_Soft_Write(addr);
    I2C_Soft_Ack_Received();

    I2C_Soft_Write(data);
    I2C_Soft_Ack_Received();
    I2C_Soft_Stop();

  //  for(i=0;i<1000;i++);
}
//_________________________________________________________________________________________________________________________________________________________
unsigned char MCP7940N_Read(unsigned char addr)
{
    unsigned char ret_val;

    I2C_Soft_Start();
    I2C_Soft_Write(MCP7940N_ADDRESS);
    I2C_Soft_Ack_Received();    //   I2C_Soft_Ack();

    I2C_Soft_Write(addr);
    I2C_Soft_Ack_Received();
    I2C_Soft_Stop();
//
    I2C_Soft_Start();
    I2C_Soft_Write(MCP7940N_ADDRESS+1);
    I2C_Soft_Ack_Received();

    ret_val=I2C_Soft_Read(addr);
    I2C_Soft_NoAck();
    I2C_Soft_Stop();
    return ret_val;
}
//_________________________________________________________________________________________________________________________________________________________
