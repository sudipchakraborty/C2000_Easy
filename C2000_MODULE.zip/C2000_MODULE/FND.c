//#include <unistd.h>
//#include <stdint.h>
//#include <stddef.h>
//#include <ti/drivers/GPIO.h>
//#include "ti_drivers_config.h"
//
//#include "FND.h"
//
//
//
//// red-vcc
//// white- gnd
//// gray- data pc35t8=
//// violet- clk pd3
//// blue - stb pe5
//
//uint8_t FND_data,FND_clock,FND_strobe,No_Of_Char,FND_Type;
////_________________________________________________________________________________________________________________________
//void FND_Init(uint8_t pin_Data, uint8_t pin_Clock, uint8_t pin_Strobe, uint8_t digit_count, uint8_t type)
//{
//    FND_data=pin_Data;
//    FND_clock=pin_Clock;
//    FND_strobe=pin_Strobe;
//    No_Of_Char=digit_count;
//    FND_Type=type;
//}
////_______________________________________________________________________________________________________________________
//void FND_Update(uint8_t *bfr)
//{
//    ConvertAscii2FND(bfr);
//    FND_Bytes_Write(bfr);
//    strobe_trigger();
//}
////___________________________________________________________________________________________________________________
//void FND_Update_Reverse(uint8_t *bfr)
//{
//    int8_t i;
//
//    i=No_Of_Char;
//    ConvertAscii2FND(bfr);
//
//    do{
//        FND_Byte_Write(*(bfr+i));
//        i--;
//    }while(i>=0);
//
//    strobe_trigger();
//}
////___________________________________________________________________________________________________________________
//void Toggle_FND_DATA_PIN(void)
//{
//    GPIO_toggle(FND_data);
//    sleep(1);
//}
////_______________________________________________________________________________________________________________________
//void Toggle_FND_CLOCK_PIN(void)
//{
//    GPIO_toggle(FND_clock);
//    sleep(1);
//}
////__________________________________________________________________________________________________________________________
//void Toggle_FND_STROBE_PIN(void)
//{
//    GPIO_toggle(FND_strobe);
//    sleep(1);
//}
////__________________________________________________________________________________________________________________________
//void FND_Send_To_All(uint8_t val)
//{
//    uint8_t i;
//
//    for(i=0;i<No_Of_Char;i++)
//    {
//        FND_Byte_Write(val);
//    }
//
//    strobe_trigger();
//}
////__________________________________________________________________________________________________________________________
//void FND_Blink_All(void)
//{
//    uint8_t i;
//
//    for(i=0;i<No_Of_Char;i++)
//    {
//        FND_Byte_Write(0x00);
//    }
//        strobe_trigger();
//        sleep(1);
//
//    for(i=0;i<No_Of_Char;i++)
//    {
//      FND_Byte_Write(0xFF);
//    }
//        strobe_trigger();
//        sleep(1);
//}
////__________________________________________________________________________________________________________________________
//void FND_Bytes_Write(uint8_t *bfr)
//{
//    uint8_t i;
//    for(i=0;i<No_Of_Char;i++)
//    {
//        FND_Byte_Write(*bfr);
//        bfr++;
//    }
//}
////__________________________________________________________________________________________________________________________
//void FND_Byte_Write(uint8_t val)
//{
//    unsigned char count;
//    count=0;
//
//    if(FND_Type==Common_Cathod) val=~val;
//
//    do
//    {
//        if(val & 0x80) GPIO_write(FND_data,1);
//        else           GPIO_write(FND_data,0);
//
//        GPIO_write(FND_clock,1);
//        GPIO_write(FND_clock,0);
//
//        val=val<<1;
//        count++;
//    }while(count<8);
//}
////__________________________________________________________________________________________________________________________
//void strobe_trigger(void)
//{
//    GPIO_write(FND_strobe,1);
//    GPIO_write(FND_strobe,0);
//}
////__________________________________________________________________________________________________________________________
//
//
//
//
//////______________________________________________________________________________
////void Print_str_to_FND(const unsigned char *str_Bfr)
////{   unsigned char bfr[10];
////    strcpy(&bfr[0],str_Bfr);
////    ConvertAscii2FND(&bfr);
////    Puts2SR(External,&bfr[0],No_Of_Char,Digit_Order);
////}
//////______________________________________________________________________________
////void Send_Int_To_FND(unsigned int val)
////{
////   unsigned char bfr[5];
////   ConvertInt2Ascii(val,&bfr[0],No_Of_Char,0);
////   UPDATE_FND(&bfr);
////}
////____________________________________________________________________________________________________________________
//void ConvertAscii2FND(unsigned char *srcptr)
//{
//    unsigned char i;
//
//    for(i=0;i<No_Of_Char;i++)
//    {
//        switch(*srcptr)
//        {
//            case 0x30:
//            *srcptr=0x3F;
//            break;
//
//            case 0x31:
//            *srcptr=0x06;
//            break;
//
//            case 0x32:
//            *srcptr=0x5B;
//            break;
//
//            case 0x33:
//            *srcptr=0x4F;
//            break;
//
//            case 0x34:
//            *srcptr=0x66;
//            break;
//
//            case 0x35:
//            *srcptr=0x6D;
//            break;
//
//            case 0x36:
//            *srcptr=0x7D;
//            break;
//
//            case 0x37:
//            *srcptr=0x07;
//            break;
//
//            case 0x38:
//            *srcptr=0x7F;
//            break;
//
//            case 0x39:
//            *srcptr=0x6F;
//            break;
//
//            case 0x3A:
//            *srcptr=0x00;
//            break;
//
//            case '-':
//            *srcptr= 0x40;
//            break;
//
//            case 'A':
//            case 'a':
//            *srcptr=0x77;
//            break;
//
//            case 'B':
//            case 'b':
//            *srcptr=0x7C;
//            break;
//
//            case 'C':
//            *srcptr=0x39;
//            break;
//
//            case 'c':
//            *srcptr=0x58;
//            break;
//
//            case 'D':
//            case 'd':
//            *srcptr=0x5E;
//            break;
//
//            case 'E':
//            case 'e':
//            *srcptr=0x79;
//            break;
//
//            case 'F':
//            case 'f':
//            *srcptr=0x71;
//            break;
//
//            case 'G':
//            case 'g':
//            *srcptr=0x6F;
//            break;
//
//            case 'H':
//            *srcptr=0x76;
//            break;
//
//            case 'h':
//            *srcptr=0x74;
//            break;
//
//            case 'i':
//            case 'I':
//            *srcptr=0x04;
//            break;
//
//            case 'L':
//            case 'l':
//            *srcptr=0x38;
//            break;
//
//            case 'N':
//            case 'n':
//            *srcptr=0x54;
//            break;
//
//            case 'O':
//            *srcptr=0x3F;
//            break;
//
//            case 'o':
//            *srcptr=0x5C;
//            break;
//
//            case 'P':
//            case 'p':
//            *srcptr=0x73;
//            break;
//
//            case 'Q':
//            case 'q':
//            *srcptr=0x67;
//            break;
//
//            case 'R':
//            case 'r':
//            *srcptr=0x50;
//            break;
//
//            case 'S':
//            case 's':
//            *srcptr=0x6D;
//            break;
//
//            case 'T':
//            case 't':
//            *srcptr=0x78;
//            break;
//
//            case 'U':
//            *srcptr=0x3E;
//            break;
//
//            case 'u':
//            *srcptr=0x1C;
//            break;
//
//            case 'V':
//            case 'v':
//            *srcptr=0x1C;
//            break;
//
//            case 'Y':
//            case 'y':
//            *srcptr=0x6E;
//            break;
//
//            default:
//            *srcptr=0x00;
//            break;
//        }
//        if(FND_Type==1)
//        {
//            *srcptr= ~(*srcptr);
//        }
//        srcptr++;
//    }
//}
