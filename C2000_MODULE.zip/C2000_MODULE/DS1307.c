
#include "F2805x_Cla_typedefs.h"    // F2806x CLA Type definitions
#include "F2805x_Device.h"          // F2805x Headerfile Include File
#include "MCP7940N.h"
//#define LED_PIN_HI   GpioDataRegs.GPASET.bit.GPIO0=1
//#define LED_PIN_LO   GpioDataRegs.GPACLEAR.bit.GPIO0=1
////_____________________________________________________________________________________________________________________
//struct RGB_LED      rgb[LED_COUNT];
//
////___________________________________________________________________________________________________________
//void WS2812B_Init(void)
//{
//    EALLOW;
//         // GpioCtrlRegs.GPAMUX1.bit.GPIO0=0;
//            GpioCtrlRegs.GPADIR.bit.GPIO0= 1;
//    EDIS;
//}
////_______________________________________________________________________________________________________
//void WS2812B_PIN_Test(void)
//{
//    GpioDataRegs.GPASET.bit.GPIO0= 1;
// //   for(i=0;i<10000;i++);   //10000
//    GpioDataRegs.GPACLEAR.bit.GPIO0= 1;
// //   for(i=0;i<10000;i++);   //10000
//}
////___________________________________________________________________________________________________________________________________________________
//void WS2812B_Action_from_Command(unsigned char *packet)
//{
//    unsigned char index,R,G,B;
//
//    unsigned char i;
//    if(*(packet+1)=='U')    // index update <U001#123,100,102>
//    {
//        index=ConvertAscii2Byte(packet+2);
//        R=ConvertAscii2Byte(packet+6);
//        G=ConvertAscii2Byte(packet+10);
//        B=ConvertAscii2Byte(packet+14);
//        WS2812B_Update_LED(index,R,G,B);
//       // WS2812B_update();
//    }
//    else if(*(packet+1)=='D')  // display <D>>
//    {
//        WS2812B_update();
//    }
//    else if(*(packet+1)=='F')  //  <F,123,100,102>\r
//    {
//       R=ConvertAscii2Byte(packet+3);
//       G=ConvertAscii2Byte(packet+7);
//       B=ConvertAscii2Byte(packet+11);
//       WS2812B_Fill(R,G,B);
//       WS2812B_update();
//    }
//    else
//    {
//
//    }
//}
////___________________________________________________________________________________________________________________________________________________
//void WS2812B_Update_LED(unsigned int index, unsigned char R,unsigned char G, unsigned char B)
//{
//    rgb[index].R=R;
//    rgb[index].G=G;
//    rgb[index].B=B;
//}
////___________________________________________________________________________________________________________________________________________________
//void WS2812B_Fill(unsigned char R,unsigned char G,unsigned char B)
//{
//    unsigned int i;
//
//     for(i=0;i<LED_COUNT;i++)
//     {
//         rgb[i].R=R;
//         rgb[i].G=G;
//         rgb[i].B=B;
//     }
//}
////___________________________________________________________________________________________________________________________________________________
//void WS2812B_update(void)
//{
//    unsigned int i;
//
//     for(i=0;i<LED_COUNT;i++)
//     {
//       WS2812B_Send_Single_RGB_LED(rgb[i].R,rgb[i].G, rgb[i].B);
//     }
//}
////__________________________________________________________________________________________________________
//void WS2812B_Send_Single_RGB_LED(unsigned char LED_R,unsigned char LED_G, unsigned char LED_B)
//{
//    register unsigned char i,val;
//
//    val=LED_G;    //G
//
//       for(i=0;i<8;i++)
//       {
//           if((val &0x80)==0)
//           {
//               WS2812B_send_Bit_0();
//           }
//           else
//           {
//               WS2812B_send_Bit_1();
//           }
//           val=val<<1;
//      }
//    //////////////////////////////////////
//    val=LED_R;
//
//    for(i=0;i<8;i++)
//    {
//        if((val &0x80)==0)
//        {
//            WS2812B_send_Bit_0();                                                                                                         ;
//        }
//        else
//        {
//            WS2812B_send_Bit_1();
//        }
//
//        val=val<<1;
//    }
//    ////////////////////////////////////
//    val=LED_B;    // B
//
//    for(i=0;i<8;i++)
//    {
//        if((val &0x80)==0)
//        {
//            WS2812B_send_Bit_0();
//        }
//        else
//        {
//            WS2812B_send_Bit_1();
//        }
//
//        val=val<<1;
//    }
//}
////_________________________________________________________________________________________________________
//void WS2812B_send_Bit_1(void)
//{
//// send T1H=1.2us
//        LED_PIN_HI;
//    __asm("   NOP");
//    __asm("   NOP");
//    __asm("   NOP");
//
//   // send T1L=1.3us
//    LED_PIN_LO;
//    __asm("   NOP");
//    __asm("   NOP");
//    __asm("   NOP");
//}
////__________________________________________________________________________________________________________
//void WS2812B_send_Bit_0(void)
//{
//    // send T0H= 0.5us
//     LED_PIN_HI;
//    __asm("   NOP");
////  send T0L= 2.0us
//    LED_PIN_LO;
//    __asm("   NOP");
//    __asm("   NOP");
//    __asm("   NOP");
//    __asm("   NOP");
//}
////______________________________________________________________________________________________________________
