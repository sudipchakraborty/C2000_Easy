#include "SCIC.h"

#include "F2805x_Cla_typedefs.h"    // F2806x CLA Type definitions
#include "F2805x_Device.h"          // F2805x Headerfile Include File
//#include "ANORA\global.h"

interrupt void scicTxFifoIsr(void);
interrupt void scicRxFifoIsr(void);

struct str_SCIC       SerialC;
//_______________________________________________________________________________________________________________________
void SCIC_Config(long baud_rate)
{
    scic_Port_Config();
    DINT;
    scic_Module_config();
    scic_Interrupt_Config();
    SCIC_Set_Baud_Rate(baud_rate);
    SCIC_set_RX();
    SCIC_Purge();
}
//_______________________________________________________________________________________________________________________
void scic_Interrupt_Config(void)
{
    EALLOW;  // This is needed to write to EALLOW protected registers
        PieVectTable.SCIRXINTC = &scicRxFifoIsr;
        PieVectTable.SCITXINTC = &scicTxFifoIsr;
    EDIS;   // This is needed to disable write to EALLOW protected registers

    PieCtrlRegs.PIECTRL.bit.ENPIE= 1;   // Enable the PIE block
    PieCtrlRegs.PIEIER9.bit.INTx1= 1;     // PIE Group 9, INT1
    PieCtrlRegs.PIEIER9.bit.INTx2= 1;     // PIE Group 9, INT2
    IER = 0x100; // Enable CPU INT

    EINT;
}
//_______________________________________________________________________________________________________________________
void scic_Port_Config(void)
{
    EALLOW;

 //  Enable if SCIC pin Changed
//    GpioCtrlRegs.GPAPUD.bit.GPIO26 = 0;  // Enable pull-up for GPIO26 (SCIRXDC)
//    GpioCtrlRegs.GPAPUD.bit.GPIO27 = 0;  // Enable pull-up for GPIO27 (SCITXDC)
//    GpioCtrlRegs.GPAQSEL2.bit.GPIO26 = 3;  // Asynch input GPIO26 (SCIRXDC)
//    GpioCtrlRegs.GPAMUX2.bit.GPIO26 = 2; // Configure GPIO26 for SCIRXDC
//    GpioCtrlRegs.GPAMUX2.bit.GPIO27 = 2; // Configure GPIO27 for SCITXDC

       GpioCtrlRegs.GPBPUD.bit.GPIO39 = 0;  // Enable pull-up for GPIO39 (SCIRXDC)
       GpioCtrlRegs.GPBPUD.bit.GPIO42 = 0;  // Enable pull-up for GPIO42 (SCITXDC)
       GpioCtrlRegs.GPBQSEL1.bit.GPIO39 = 3;  // Asynch input GPIO39 (SCIRXDC)
       GpioCtrlRegs.GPBMUX1.bit.GPIO39 = 2; // Configure GPIO39 for SCIRXDC
       GpioCtrlRegs.GPBMUX1.bit.GPIO42 = 2; // Configure GPIO42 for SCITXDC

       EDIS;


    EALLOW;
    //      GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 0;
    //      GpioCtrlRegs.GPADIR.bit.GPIO9 = 1;
    EDIS;
}
//_______________________________________________________________________________________________________________________
void scic_Module_config(void)
{
    ScicRegs.SCICCR.all = 0x0007;           // 1 stop bit,  No loopback,No parity,8 char bits, async mode, idle-line protocol
    ScicRegs.SCICTL1.all = 0x0003;          // enable TX, RX, internal SCICLK, Disable RX ERR, SLEEP, TXWAKE
    ScicRegs.SCICTL2.bit.TXINTENA = 1;
    ScicRegs.SCICTL2.bit.RXBKINTENA = 1;
 //   Set_Baud_Rate(9600);
    ScicRegs.SCICCR.bit.LOOPBKENA =0;       // 1; // Enable loop back
    ScicRegs.SCIFFTX.all = 0xC022;
    ScicRegs.SCIFFRX.all = 0x0022;
    ScicRegs.SCIFFCT.all = 0x00;

    ScicRegs.SCICTL1.all = 0x0023;          // Relinquish SCI from Reset
    // SciaRegs.SCIFFTX.bit.TXFIFOXRESET = 1;
    ScicRegs.SCIFFRX.bit.RXFIFORESET = 1;
}
//_______________________________________________________________________________________________________________________
interrupt void scicTxFifoIsr(void)
{
    if(SerialC.scic_bfr_ptr_tx<SerialC.scic_tx_count+1)
    {
        ScicRegs.SCITXBUF=SerialC.scic_bfr_tx[SerialC.scic_bfr_ptr_tx];
        SerialC.scic_bfr_ptr_tx++;
        ScicRegs.SCITXBUF=SerialC.scic_bfr_tx[SerialC.scic_bfr_ptr_tx];
        SerialC.scic_bfr_ptr_tx++;
    }
    else
    {
        ScicRegs.SCIFFTX.bit.TXFIFOXRESET =0;
        SCIC_set_RX();
    }
    ScicRegs.SCIFFTX.bit.TXFFINTCLR = 1;  // Clear SCI Interrupt flag
    PieCtrlRegs.PIEACK.all |= 0x100;      // Issue PIE ACK
}
//_______________________________________________________________________________________________________________________
interrupt void scicRxFifoIsr(void)
{
    SerialC.scic_bfr_rx[SerialC.scic_bfr_ptr_rx] = ScicRegs.SCIRXBUF.all;        // Read data
    if(SerialC.scic_bfr_ptr_rx<scic_bfr_count)  SerialC.scic_bfr_ptr_rx++;
    SerialC.scic_bfr_rx[SerialC.scic_bfr_ptr_rx] = ScicRegs.SCIRXBUF.all;        // Read data
    if(SerialC.scic_bfr_ptr_rx<scic_bfr_count)  SerialC.scic_bfr_ptr_rx++;

    ScicRegs.SCIFFRX.bit.RXFFOVRCLR = 1;   // Clear Overflow flag
    ScicRegs.SCIFFRX.bit.RXFFINTCLR = 1;   // Clear Interrupt flag

    PieCtrlRegs.PIEACK.all |= 0x100;       // Issue PIE ack
}
//_______________________________________________________________________________________________________________________
unsigned char scic_Data_Received(void)
{
    if(SerialC.scic_bfr_ptr_rx>0) return -1;
    else return 0;
}
//_______________________________________________________________________________________________________________________
void scic_send(unsigned char *bfr, unsigned int count)
{
    unsigned char i;
    double delay_reg;

 //   SCIC_set_TX();

    for(i=0;i<count;i++)
    {
        SerialC.scic_bfr_tx[i]= *bfr;
        bfr++;
    }
    SerialC.scic_bfr_ptr_tx=0;
    SerialC.scic_tx_count=count;
    ScicRegs.SCIFFTX.bit.TXFIFOXRESET = 1;

    for(delay_reg=0;delay_reg<count*40;delay_reg++);
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIC_set_TX(void)
{
    unsigned int i;
 //   for(i=0;i<10000;i++);
 //   GpioDataRegs.GPASET.bit.GPIO9= 1;
 //   for(i=0;i<10000;i++);   //10000
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIC_set_RX(void)
{
    unsigned int i;
 //   for(i=0;i<10000;i++);
 //   GpioDataRegs.GPACLEAR.bit.GPIO9 = 1;
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIC_Set_Baud_Rate(long baud_rate)
{
    switch(baud_rate)
    {
        case 9600:      ScicRegs.SCILBAUD=0x00C2;   break;
        case 19200:     ScicRegs.SCILBAUD=0x0061;   break;
        case 38400:     ScicRegs.SCILBAUD=0x0030;   break;
        case 115200:    ScicRegs.SCILBAUD=15;       break;
        default:        ScicRegs.SCILBAUD=0x00C2;   break;
    }
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIC_Purge(void)
{
    unsigned int i;

    SerialC.scic_bfr_ptr_rx=0;
    SerialC.scic_bfr_ptr_tx=0;

    for(i=0;i<scic_bfr_count;i++)
    {
        SerialC.scic_bfr_tx[i]=0x00;
        SerialC.scic_bfr_rx[i]=0x00;
    }

//    SciaRegs.SCIFFRX.bit.RXFFST=0;
//    SerialA.ptr_rx=0;
}
//___________________________________________________________________________________________________________________________________________________________________________________________















//void SCIA_Read_Line(unsigned char *bfr)
//{
//    Uint16 ReceivedChar;
//    SCIA_set_RX();
//
//    for(;;)
//    {
//          while(SciaRegs.SCIFFRX.bit.RXFFST !=1);
//          ReceivedChar = SciaRegs.SCIRXBUF.all;
//          if(ReceivedChar=='\r') return;
//          else
//          {
//              *bfr=ReceivedChar;
//              bfr++;
//          }
//    }
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//unsigned char SCIA_Data_Received(void)
//{
////    if(SciaRegs.SCIFFRX.bit.RXFFST ==0) return 0;
////    SerialA.bfr[SerialA.ptr_rx] = SciaRegs.SCIRXBUF.all;
////    SerialA.ptr_rx++;
////    return -1;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//unsigned char SCIA_Received(void)
//{
////    unsigned char ReceivedChar;
////
////    if(SciaRegs.SCIFFRX.bit.RXFFST ==0) return;
////    ReceivedChar = SciaRegs.SCIRXBUF.all;
////    if(ReceivedChar=='\r')
////    {
////        SerialA.ptr_rx=0;
////        return -1;
////    }
////    else
////    {
////       SerialA.bfr[SerialA.ptr_rx]=ReceivedChar;
////       SerialA.ptr_rx++;
////    }
////    return 0;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//void set_Test_Baud_Val(unsigned char val)
//{
//    SciaRegs.SCILBAUD    =val;
//}

//_______________________________________________________________________________________________________________________
//void SCIA_msg(char * msg)
//{
//    int i,j;
//
//    SCIA_set_TX();
//
//    i = 0;
//   do     //while(*(msg+i) != '\0')
//    {
//       j=*(msg+i);
//        SCIA_put(j);
//        i++;
//    }while(i != 9);// while(i<8);
//    SCIA_set_RX();
//}
//________________________________________________________________________________________________________________________________________________________
//void SCIA_msg_by_count(char * msg,unsigned char count)
//{
//    int i;
//    SCIA_set_TX();
//    i = 0;
//    do
//    {
//        SCIA_put(*(msg+i));
//        i++;
//    }while(i<=count+1);
//    SCIA_set_RX();
//}
////________________________________________________________________________________________________________________________________________________________
//void SCIA_Send(unsigned char * msg,unsigned char count)
//{
//    while(count>0)
//    {
//        SCIA_put(*msg);
//        count--;
//        msg++;
//    }
//    SCIA_set_RX();
//}
////____________________________________________________________________________________________________________________________________________________________________________________________
//void SCIA_put(int a)
//{
//    while (SciaRegs.SCIFFTX.bit.TXFFST != 0);
//    SciaRegs.SCITXBUF=a;
//}


