#ifndef SCIA_H_
#define SCIA_H_

#define scia_bfr_count   20
///////////////////////////
void SCIA_Config(long baud_rate);
void scia_Port_Config(void);
void scia_Interrupt_Config(void);
void SCIA_msg(char * msg);
void SCIA_put(int a);
void SCIA_set_TX(void);
void SCIA_set_RX(void);
void SCIA_Read_Line(unsigned char *bfr);
void set_Test_Baud_Val(unsigned char val);
void Set_Baud_Rate(long baud_rate);
void SCIA_Purge(void);
unsigned char SCIA_Received(void);
unsigned char SCIA_Data_Received(void);
void SCIA_msg_by_count(char * msg,unsigned char count);
void SCIA_Send(unsigned char * msg,unsigned char count);
unsigned char scia_Data_Received(void);
void scia_send(unsigned char *bfr, unsigned int count);
///////////////////////////
struct str_SCIA
{
    unsigned char scia_bfr_rx[scia_bfr_count];
    unsigned char scia_bfr_tx[scia_bfr_count];
    unsigned char scia_bfr_ptr_rx;
    unsigned char scia_bfr_ptr_tx;
    unsigned char scia_tx_count;
    unsigned char scia_received;
};






























#endif /* SCIA_H_ */
