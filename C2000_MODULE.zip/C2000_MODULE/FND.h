#ifndef FND_H_
#define FND_H_
//////////////////////////
enum fnd_type
{
    Common_Cathod,
    Common_Anode
};
//////////////////////////
void FND_Init(uint8_t pin_Data, uint8_t pin_Clock, uint8_t pin_Strobe, uint8_t digit_count, uint8_t type);
void Toggle_FND_DATA_PIN(void);
void Toggle_FND_CLOCK_PIN(void);
void Toggle_FND_STROBE_PIN(void);
void FND_Bytes_Write(uint8_t *bfr);
void FND_Byte_Write(uint8_t val);
void strobe_trigger(void);
void ConvertAscii2FND(uint8_t *srcptr);
void FND_Update(uint8_t *bfr);
void FND_Update_Reverse(uint8_t *bfr);
void FND_Blink_All(void);
void FND_Send_To_All(uint8_t val);

#endif
