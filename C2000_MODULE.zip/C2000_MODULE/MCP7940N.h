



void MCP7940N_Write(unsigned char addr, unsigned char data);
unsigned char MCP7940N_Read(unsigned char addr);
