/*
 * global.h
 *
 *  Created on: 14-May-2022
 *      Author: Dr. S Chakraborty
 */

#ifndef ANORA_GLOBAL_H_
#define ANORA_GLOBAL_H_


#define     true        1
#define     TRUE        1
#define     True        1
#define     False       0
//#define     false       0
#define     FALSE       0
#define     yes         1
#define     YES         1
#define     No          0
#define     NO          0
#define     Cancel      0
#define     CANCEL      0



#endif /* ANORA_GLOBAL_H_ */
