#include "SCIA.h"

#include "F2805x_Cla_typedefs.h"    // F2806x CLA Type definitions
#include "F2805x_Device.h"          // F2805x Headerfile Include File
//#include "ANORA\global.h"

interrupt void sciaTxFifoIsr(void);
interrupt void sciaRxFifoIsr(void);

struct str_SCIA       SerialA;
//_______________________________________________________________________________________________________________________
void SCIA_Config(long baud_rate)
{
    scia_Port_Config();
    DINT;
    scia_Module_config();
    scia_Interrupt_Config();
    Set_Baud_Rate(baud_rate);
    SCIA_set_RX();
    SCIA_Purge();
}
//_______________________________________________________________________________________________________________________
void scia_Interrupt_Config(void)
{
    EALLOW;  // This is needed to write to EALLOW protected registers
        PieVectTable.SCIRXINTA = &sciaRxFifoIsr;
        PieVectTable.SCITXINTA = &sciaTxFifoIsr;
    EDIS;   // This is needed to disable write to EALLOW protected registers

    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;   // Enable the PIE block
    PieCtrlRegs.PIEIER9.bit.INTx1= 1;     // PIE Group 9, INT1
    PieCtrlRegs.PIEIER9.bit.INTx2= 1;     // PIE Group 9, INT2
    IER = 0x100; // Enable CPU INT

    EINT;
}
//_______________________________________________________________________________________________________________________
void scia_Port_Config(void)
{
    EALLOW;
         GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;     // Enable pull-up for GPIO28 (SCIRXDA)
         GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;     // Enable pull-up for GPIO29 (SCITXDA)
         GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 3;   // Asynch input GPIO28 (SCIRXDA)
         GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 1;    // Configure GPIO28 for SCIRXDA
         GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 1;    // Configure GPIO29 for SCITXDA
    EDIS;


    EALLOW;
          GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 0;
          GpioCtrlRegs.GPADIR.bit.GPIO9 = 1;
    EDIS;
}
//_______________________________________________________________________________________________________________________
void scia_Module_config(void)
{
    SciaRegs.SCICCR.all = 0x0007;           // 1 stop bit,  No loopback,No parity,8 char bits, async mode, idle-line protocol
    SciaRegs.SCICTL1.all = 0x0003;          // enable TX, RX, internal SCICLK, Disable RX ERR, SLEEP, TXWAKE
    SciaRegs.SCICTL2.bit.TXINTENA = 1;
    SciaRegs.SCICTL2.bit.RXBKINTENA = 1;
    Set_Baud_Rate(9600);
    SciaRegs.SCICCR.bit.LOOPBKENA =0;       // 1; // Enable loop back
    SciaRegs.SCIFFTX.all = 0xC022;
    SciaRegs.SCIFFRX.all = 0x0022;
    SciaRegs.SCIFFCT.all = 0x00;

    SciaRegs.SCICTL1.all = 0x0023;          // Relinquish SCI from Reset
    // SciaRegs.SCIFFTX.bit.TXFIFOXRESET = 1;
    SciaRegs.SCIFFRX.bit.RXFIFORESET = 1;
}
//_______________________________________________________________________________________________________________________
interrupt void sciaTxFifoIsr(void)
{
    if(SerialA.scia_bfr_ptr_tx<SerialA.scia_tx_count+1)
    {
        SciaRegs.SCITXBUF=SerialA.scia_bfr_tx[SerialA.scia_bfr_ptr_tx];
        SerialA.scia_bfr_ptr_tx++;
        SciaRegs.SCITXBUF=SerialA.scia_bfr_tx[SerialA.scia_bfr_ptr_tx];
        SerialA.scia_bfr_ptr_tx++;
    }
    else
    {
        SciaRegs.SCIFFTX.bit.TXFIFOXRESET =0;
        SCIA_set_RX();
    }
    SciaRegs.SCIFFTX.bit.TXFFINTCLR = 1;  // Clear SCI Interrupt flag
    PieCtrlRegs.PIEACK.all |= 0x100;      // Issue PIE ACK
}
//_______________________________________________________________________________________________________________________
interrupt void sciaRxFifoIsr(void)
{
    SerialA.scia_bfr_rx[SerialA.scia_bfr_ptr_rx] = SciaRegs.SCIRXBUF.all;        // Read data
    if(SerialA.scia_bfr_ptr_rx<scia_bfr_count)  SerialA.scia_bfr_ptr_rx++;
    SerialA.scia_bfr_rx[SerialA.scia_bfr_ptr_rx] = SciaRegs.SCIRXBUF.all;        // Read data
    if(SerialA.scia_bfr_ptr_rx<scia_bfr_count)  SerialA.scia_bfr_ptr_rx++;

    SciaRegs.SCIFFRX.bit.RXFFOVRCLR = 1;   // Clear Overflow flag
    SciaRegs.SCIFFRX.bit.RXFFINTCLR = 1;   // Clear Interrupt flag

    PieCtrlRegs.PIEACK.all |= 0x100;       // Issue PIE ack
}
//_______________________________________________________________________________________________________________________
unsigned char scia_Data_Received(void)
{
    if(SerialA.scia_bfr_ptr_rx>0) return -1;
    else return 0;
}
//_______________________________________________________________________________________________________________________
void scia_send(unsigned char *bfr, unsigned int count)
{
    unsigned char i;
    double delay_reg;

    SCIA_set_TX();

    for(i=0;i<count;i++)
    {
        SerialA.scia_bfr_tx[i]= *bfr;
        bfr++;
    }
    SerialA.scia_bfr_ptr_tx=0;
    SerialA.scia_tx_count=count;
    SciaRegs.SCIFFTX.bit.TXFIFOXRESET = 1;

    for(delay_reg=0;delay_reg<count*40;delay_reg++);
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIA_set_TX(void)
{
    unsigned int i;
 //   for(i=0;i<10000;i++);
    GpioDataRegs.GPASET.bit.GPIO9= 1;
 //   for(i=0;i<10000;i++);   //10000
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIA_set_RX(void)
{
    unsigned int i;
 //   for(i=0;i<10000;i++);
    GpioDataRegs.GPACLEAR.bit.GPIO9 = 1;
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void Set_Baud_Rate(long baud_rate)
{
    switch(baud_rate)
    {
        case 9600:      SciaRegs.SCILBAUD=0x00C2;   break;
        case 19200:     SciaRegs.SCILBAUD=0x0061;   break;
        case 38400:     SciaRegs.SCILBAUD=0x0030;   break;
        case 115200:    SciaRegs.SCILBAUD=15;       break;
        default:        SciaRegs.SCILBAUD=0x00C2;   break;
    }
}
//___________________________________________________________________________________________________________________________________________________________________________________________
void SCIA_Purge(void)
{
    unsigned int i;

    SerialA.scia_bfr_ptr_rx=0;
    SerialA.scia_bfr_ptr_tx=0;

    for(i=0;i<scia_bfr_count;i++)
    {
        SerialA.scia_bfr_tx[i]=0x00;
        SerialA.scia_bfr_rx[i]=0x00;
    }

//    SciaRegs.SCIFFRX.bit.RXFFST=0;
//    SerialA.ptr_rx=0;
}
//___________________________________________________________________________________________________________________________________________________________________________________________















//void SCIA_Read_Line(unsigned char *bfr)
//{
//    Uint16 ReceivedChar;
//    SCIA_set_RX();
//
//    for(;;)
//    {
//          while(SciaRegs.SCIFFRX.bit.RXFFST !=1);
//          ReceivedChar = SciaRegs.SCIRXBUF.all;
//          if(ReceivedChar=='\r') return;
//          else
//          {
//              *bfr=ReceivedChar;
//              bfr++;
//          }
//    }
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//unsigned char SCIA_Data_Received(void)
//{
////    if(SciaRegs.SCIFFRX.bit.RXFFST ==0) return 0;
////    SerialA.bfr[SerialA.ptr_rx] = SciaRegs.SCIRXBUF.all;
////    SerialA.ptr_rx++;
////    return -1;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//unsigned char SCIA_Received(void)
//{
////    unsigned char ReceivedChar;
////
////    if(SciaRegs.SCIFFRX.bit.RXFFST ==0) return;
////    ReceivedChar = SciaRegs.SCIRXBUF.all;
////    if(ReceivedChar=='\r')
////    {
////        SerialA.ptr_rx=0;
////        return -1;
////    }
////    else
////    {
////       SerialA.bfr[SerialA.ptr_rx]=ReceivedChar;
////       SerialA.ptr_rx++;
////    }
////    return 0;
//}
////___________________________________________________________________________________________________________________________________________________________________________________________
//void set_Test_Baud_Val(unsigned char val)
//{
//    SciaRegs.SCILBAUD    =val;
//}

//_______________________________________________________________________________________________________________________
void SCIA_msg(char * msg)
{
    int i,j;

    SCIA_set_TX();

    i = 0;
   do     //while(*(msg+i) != '\0')
    {
       j=*(msg+i);
        SCIA_put(j);
        i++;
    }while(i != 9);// while(i<8);
    SCIA_set_RX();
}
//________________________________________________________________________________________________________________________________________________________
//void SCIA_msg_by_count(char * msg,unsigned char count)
//{
//    int i;
//    SCIA_set_TX();
//    i = 0;
//    do
//    {
//        SCIA_put(*(msg+i));
//        i++;
//    }while(i<=count+1);
//    SCIA_set_RX();
//}
////________________________________________________________________________________________________________________________________________________________
void SCIA_Send(unsigned char * msg,unsigned char count)
{
    while(count>0)
    {
        SCIA_put(*msg);
        count--;
        msg++;
    }
    SCIA_set_RX();
}
////____________________________________________________________________________________________________________________________________________________________________________________________
void SCIA_put(int a)
{
    while (SciaRegs.SCIFFTX.bit.TXFFST != 0);
    SciaRegs.SCITXBUF=a;
}


