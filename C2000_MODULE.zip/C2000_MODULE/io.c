#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include "io.h"


//___________________________________________________________________________________________________
void pinMode(unsigned char pin, unsigned char direction)
{
   EALLOW;

   switch(pin)
   {
       case 1:  GpioCtrlRegs.GPADIR.bit.GPIO22 = direction; break;
       case 2:  GpioCtrlRegs.GPBDIR.bit.GPIO32 = direction; break;
       case 3:  GpioCtrlRegs.GPBDIR.bit.GPIO33 = direction; break;
       case 40: GpioCtrlRegs.GPADIR.bit.GPIO26 = direction; break;
       case 45: GpioCtrlRegs.GPADIR.bit.GPIO8 =  direction; break;
       case 46: GpioCtrlRegs.GPADIR.bit.GPIO25=  direction; break;
       case 49: GpioCtrlRegs.GPADIR.bit.GPIO7 =  direction; break;
       case 50: GpioCtrlRegs.GPADIR.bit.GPIO6 =  direction; break;
       case 55: GpioCtrlRegs.GPADIR.bit.GPIO19 = direction; break;
       case 62: GpioCtrlRegs.GPADIR.bit.GPIO5 =  direction; break;
       case 63: GpioCtrlRegs.GPADIR.bit.GPIO4 =  direction; break;
       case 66: GpioCtrlRegs.GPADIR.bit.GPIO3 =  direction; break;
       case 67: GpioCtrlRegs.GPADIR.bit.GPIO2 =  direction; break;
       case 68: GpioCtrlRegs.GPADIR.bit.GPIO1 =  direction; break;
       case 69: GpioCtrlRegs.GPADIR.bit.GPIO0 =  direction; break;
       case 75: GpioCtrlRegs.GPADIR.bit.GPIO15 = direction; break;
       case 76: GpioCtrlRegs.GPADIR.bit.GPIO13 = direction; break;
       case 78: GpioCtrlRegs.GPADIR.bit.GPIO20 = direction; break;
       case 79: GpioCtrlRegs.GPADIR.bit.GPIO21 = direction; break;
       default: break;
   }
   EDIS;
}
//___________________________________________________________________________________________________
void digitalWrite(unsigned char pin, unsigned char val)
{
    switch(pin)
      {
        case  1: GpioDataRegs.GPADAT.bit.GPIO22=val;    break;
        case  2: GpioDataRegs.GPBDAT.bit.GPIO32=val;    break;
        case  3: GpioDataRegs.GPBDAT.bit.GPIO33 =val;   break;
        case 40: GpioDataRegs.GPADAT.bit.GPIO26=val;    break;
        case 45: GpioDataRegs.GPADAT.bit.GPIO8=val;     break;
        case 46: GpioDataRegs.GPADAT.bit.GPIO25=val;    break;
        case 49: GpioDataRegs.GPADAT.bit.GPIO7=val;     break;
        case 50: GpioDataRegs.GPADAT.bit.GPIO6=val;     break;
        case 55: GpioDataRegs.GPADAT.bit.GPIO19=val;    break;
        case 62: GpioDataRegs.GPADAT.bit.GPIO5=val;     break;
        case 63: GpioDataRegs.GPADAT.bit.GPIO4=val;     break;
        case 66: GpioDataRegs.GPADAT.bit.GPIO3=val;     break;
        case 67: GpioDataRegs.GPADAT.bit.GPIO2=val;     break;
        case 68: GpioDataRegs.GPADAT.bit.GPIO1=val;     break;
        case 69: GpioDataRegs.GPADAT.bit.GPIO0=val;     break;
        case 75: GpioDataRegs.GPADAT.bit.GPIO15=val;    break;
        case 76: GpioDataRegs.GPADAT.bit.GPIO13=val;    break;
        case 78: GpioDataRegs.GPADAT.bit.GPIO20=val;    break;
        case 79: GpioDataRegs.GPADAT.bit.GPIO21=val;    break;
        default: break;
      }
}
//___________________________________________________________________________________________________
unsigned char digitalRead(unsigned char pin)
{
    switch(pin)
      {
        case  2: return GpioDataRegs.GPBDAT.bit.GPIO32;
        case  3: return GpioDataRegs.GPBDAT.bit.GPIO33;
        default: break;
      }
}
//________________________________________________________________________________________________________________________________________________________________________________________
void toggle(unsigned char pin)
{
    switch(pin)
      {
        case  1: GpioDataRegs.GPATOGGLE.bit.GPIO22=1; break;
        case 40: GpioDataRegs.GPATOGGLE.bit.GPIO26=1; break;
        case 45: GpioDataRegs.GPATOGGLE.bit.GPIO8=1; break;
        case 49: GpioDataRegs.GPATOGGLE.bit.GPIO7=1; break;
        case 50: GpioDataRegs.GPATOGGLE.bit.GPIO6=1; break;
        case 55: GpioDataRegs.GPATOGGLE.bit.GPIO19=1; break;
        case 62: GpioDataRegs.GPATOGGLE.bit.GPIO5=1; break;
        case 63: GpioDataRegs.GPATOGGLE.bit.GPIO4=1; break;
        case 66: GpioDataRegs.GPATOGGLE.bit.GPIO3=1; break;
        case 67: GpioDataRegs.GPATOGGLE.bit.GPIO2=1; break;
        case 68: GpioDataRegs.GPATOGGLE.bit.GPIO1=1; break;
        case 69: GpioDataRegs.GPATOGGLE.bit.GPIO0=1; break;
        case 75: GpioDataRegs.GPATOGGLE.bit.GPIO15=1; break;
        case 76: GpioDataRegs.GPATOGGLE.bit.GPIO13=1; break;
        case 78: GpioDataRegs.GPATOGGLE.bit.GPIO20=1; break;
        case 79: GpioDataRegs.GPATOGGLE.bit.GPIO21=1; break;
        default: break;
      }
}
//________________________________________________________________________________________________________________________________________________________________________________________







