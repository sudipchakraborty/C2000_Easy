#ifndef MODBUS_H_
#define MODBUS_H_

#define     bool        unsigned char
#define     false       0
#define     true        1

#define ERROR_UTILITY_NONE 0
#define ERROR_UTILITY_BASE 30
#define ERROR_MODBUS_NONE 0
#define ERROR_MODBUS_HOLDINGREG_SIZE 1
#define ERROR_MODBUS_BASE 20
#define ERROR_MODBUS_DATA_ADDRESS 2
#define ERROR_MODBUS_DATA_VALUE 3
///////////////////////////////////
typedef enum
{
    NO_ERROR = 0,
    ILLEGAL_FUNCTION=0x01,
    ILLEGAL_DATA_ADDRESS,
    ILLEGAL_DATA_VALUE,
    SLAVE_DEVICE_FAILURE,
    ACKNOWLEDGE,
    SLAVE_DEVICE_BUSY,
    MEMORY_PARITY_ERROR=0x08,
    GATEWAY_PATH_UNAVAILABLE=0x0A,
    TARGET_FAILED_TO_RESPOND=0x0B
} MODBUS_EXCEPTIONS;
///////////////////////////////
typedef enum
{
    WRITE_MULTIPLE_REGISTER = 0x10,
    READ_HOLDING_REGISTER=0x03,
    WRITE_SINGLE_REGISTER=0x06
} MODBUS_FUNCTIONS;
///////////////////////////////////
typedef enum
{
    MODBUS_STATE_IDLE = 0,
    MODBUS_STATE_FRAME_RECEIVING=1,
    MODBUS_STATE_FRAME_RECEIVED = 2,
    MODBUS_STATE_PROCESSING = 3
}ModbusState;
//////////////////////////////////
typedef struct
{
    unsigned char function_code;
    unsigned char data[64];
    unsigned char len;
}ModbusPdu;
///////////////////////////////
typedef struct
{
    unsigned char address;
    ModbusPdu modbus_pdu;
    unsigned int crc;
}ModbusAdu;
//////////////////////////////////
typedef struct
{
    unsigned int address;
    unsigned char length;
} ModbusRegister;
/////////////////////////////////
struct modbus
{
    unsigned char FSM;
    unsigned char MODBUS_RECEIVED_BYTES;
    unsigned char MODBUS_TRANSMITTED_BYTES;
    unsigned char MODBUS_USART_RECEIVE_FLAG;
    unsigned char MODBUS_TIMER_FLAG;
    unsigned char ERROR_ADDRESS;
    unsigned char HOLDING_REGISTER_SIZE;
    unsigned int  HOLDING_REGISTER[100];
    unsigned char slave_address; //98
    unsigned char multi_cast_address; //51
    unsigned char timer_enabled:1;
};
//////////////////////////////////////////
void initialize_modbus_structure(void);
unsigned char initialize_holding_registers(void);
unsigned char deserialize_8bits_to_16bits(unsigned char * data,unsigned int * dataOut, unsigned int inputCount);
unsigned char serialize_16bits_to_8bits(unsigned int * data, unsigned char * dataOut, unsigned int inputCount);
unsigned char modbus_action_function(unsigned int);
unsigned char read_holding_registers(ModbusPdu* request, ModbusPdu* response);
unsigned char write_single_register(ModbusPdu* request, ModbusPdu* response);
unsigned char write_multiple_register(ModbusPdu* request, ModbusPdu* response);
unsigned char modbus_handler(unsigned char *bfr_request,unsigned char recv_count, unsigned char *bfr_response);
void modbus_tx_en(bool);
unsigned char modbus_rx_byte();
void modbus_tx_byte(unsigned char);
void modbus_tx_en_delay();
void modbus_enable_timer(unsigned char enable);
// Available function for the application
void modbus_Init(unsigned char device_addr);
void register_slave_address(unsigned char slave_address);
void register_multi_cast_adress(unsigned char addr);
unsigned char get_holding_registers(ModbusRegister *reg, unsigned int * data,unsigned char regCount);
unsigned char set_holding_registers(ModbusRegister *reg, unsigned int * data, unsigned char regCount, unsigned int padVal);
unsigned char set_holding_registers_string(ModbusRegister *reg, unsigned char * data, unsigned char regCount, unsigned char padVal);
void set_modbus_register_info(ModbusRegister *reg, unsigned int add, unsigned char len);
unsigned int modbus_silent_interval(float cpu_clk, unsigned int timer_div, unsigned int baud_rate);
unsigned int crc16_update(unsigned int crc, unsigned char a);
///////////////////////////////////

#endif
